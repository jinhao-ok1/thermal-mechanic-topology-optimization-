#! /user/bin/python
#-*-coding: UTF-8-*-
# -*- coding: mbcs -*-
# Do not delete the following import lines
"""code by Hao Jin"""
from abaqus import *
from abaqusConstants import *
import __main__
from part import *
from material import *
from section import *
from assembly import *
from step import *
from interaction import *
from load import *
from mesh import *
from optimization import *
from job import *
from sketch import *
from visualization import *
from connectorBehavior import *
from odbAccess import*
from textRepr import prettyPrint
from numpy import linalg
import time
from os.path import exists
import math,customKernel
from abaqus import getInput,getInputs
from odbAccess import openOdb
import xyPlot
import regionToolset
import displayGroupOdbToolset as dgo
import displayGroupMdbToolset as dgm
import sys, os, glob
import numpy as np
import numpy

# ��ODB�ļ����޸�Ϊ����ļ�·����
def IsoSmooth(odb_path):
    odb = openOdb(odb_path, readOnly=False)
    SS_ele = odb.rootAssembly.elementSets[' ALL ELEMENTS'].elements
    VS_ele = odb.rootAssembly.instances['PART-1-1'].elementSets['VS'].elements
    Ele_dict = {}
    Ele_Label = []
    Ele_Value = []

    for i in SS_ele:
        Ele_dict[i.label] = 1.0
        Ele_Label.append(i.label)
        Ele_Value.append(1.0)
        
    for j in VS_ele:
        Ele_dict[j.label] = 0.0
        Ele_Label.append(j.label)
        Ele_Value.append(0.0)   

    Ele_Label = tuple(Ele_Label) 
    Ele_Value = tuple((x,) for x in Ele_Value)
        
    fo = odb.steps['Step-1'].frames[-1].FieldOutput(name="Virtual Density", 
        description="x_e", 
        type=SCALAR) 

    fo.addData(position=CENTROID, 
        instance=odb.rootAssembly.instances['PART-1-1'], 
        labels=Ele_Label, 
        data=Ele_Value)
    odb.save() 
    odb.close()   




    
