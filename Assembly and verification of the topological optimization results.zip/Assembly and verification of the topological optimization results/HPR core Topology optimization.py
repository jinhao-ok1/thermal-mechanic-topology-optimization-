#! /user/bin/python
#-*-coding: UTF-8-*-
# -*- coding: mbcs -*-
"""Code by Hao Jin"""
from abaqus import *
from abaqusConstants import *
from abaqus import getInput,getInputs
from odbAccess import openOdb
from job import *
import numpy as np
import mmap
import regionToolset
import load
import math,customKernel
import os
import re
import shutil
execfile('IsoSmooth.py')
execfile('JiaoHE.py')
## Function of formatting Abaqus model for stiffness optimisation
def fmtMdb(Mdb):
    mdl = Mdb.models['Model-1']
    part = mdl.parts['Part-1']
    # Build sections and assign solid section
    mdl.Material(name='Material01')
    mdl.materials['Material01'].Density(table=((4.5e-09, ), ))
    mdl.materials['Material01'].Elastic(table=((145000, 0.31), ))
    mdl.materials['Material01'].Expansion(table=((2.04631E-05, ), ))
    mdl.materials['Material01'].Conductivity(table=((26, ), ))    
    mdl.PEGSection(name='sldSec', material='Material01', thickness=1500.0, wedgeAngle1=0.0, wedgeAngle2=0.0)

    mdl.Material(name='Material02')
    mdl.materials['Material02'].Density(table=((4.5e-09*0.001**3, ), ))
    mdl.materials['Material02'].Elastic(table=((145000*0.001**3, 0.31), ))
    mdl.materials['Material02'].Expansion(table=((2.04631E-05*0.001**3, ), ))
    mdl.materials['Material02'].Conductivity(table=((26*0.001**3, ), ))    
    mdl.PEGSection(name='voidSec', material='Material02', thickness=1500.0, wedgeAngle1=0.0, wedgeAngle2=0.0)
    
## Function of running FEA for raw sensitivities and objective function 
def FEA(Iter,Mdb,Xe,Ae,w2,w3,w4):
    Mdb.Job(name='Design_Job'+str(Iter), model='Model-1', description='', type=ANALYSIS, 
    atTime=None, waitMinutes=0, waitHours=0, queue=None, memory=90, 
    memoryUnits=PERCENTAGE, getMemoryFromAnalysis=True, 
    explicitPrecision=SINGLE, nodalOutputPrecision=SINGLE, echoPrint=OFF, 
    modelPrint=OFF, contactPrint=OFF, historyPrint=OFF, userSubroutine='', 
    scratch='', resultsFormat=ODB, multiprocessingMode=THREADS, numCpus=8, 
    numDomains=8, numGPUs=0) 
    Mdb.Job('Design_Job'+str(Iter),'Model-1').submit()
    Mdb.jobs['Design_Job'+str(Iter)].waitForCompletion()
    
    opdb = openOdb('Design_Job'+str(Iter)+'.odb')
    region_set = opdb.rootAssembly.instances['PART-1-1'].elementSets['SET-OPTDOMAIN']
    #region_set_nodes = opdb.rootAssembly.instances['PART-1-1'].nodeSets['SET-OPTDOMAIN']
    region_set_nodes = opdb.rootAssembly.instances['PART-1-1']
    seng_ENERGY = opdb.steps['Step-1'].frames[-1].fieldOutputs['ESEDEN'].getSubset(region=region_set).values        #提取单元应变能
    #seng_HFL = opdb.steps['Step-1'].frames[-1].fieldOutputs['HFL'].getSubset(region=region_set).values             #提取单元热流
    seng_TEMP = opdb.steps['Step-1'].frames[-1].fieldOutputs['TEMP'].getSubset(region=region_set).values           #提取单元温度
    seng_MISES = opdb.steps['Step-1'].frames[-1].fieldOutputs['S'].getSubset(region=region_set,position=CENTROID).values #质心处的值
    seng_Displacement = opdb.steps['Step-1'].frames[-1].fieldOutputs['U'].getSubset(region=region_set_nodes).values #提取节点位移

    ###创建节点位移字典，Key是节点编号，值依次是u,v
    Node_Displacement = {}
    for i in seng_Displacement: Node_Displacement[i.nodeLabel]=(i.data[0],i.data[1])

    ###创建节点坐标字典，Key是节点编号，值是节点x,y,z坐标
    Node_Coordinate = {}
    for i in nds: Node_Coordinate[i.label]=(i.coordinates[0],i.coordinates[1],i.coordinates[2])

    ###创建单元的位移向量，Key是单元编号，值是[u1,v1,u2,v2,u3,v3,u4,v4]
    Ele_Node_Displacement = {};Ele_Node_Displacement_Voctor = {}
    for i in part.elements:
        Ele_Node_Displacement[i.label] = (Node_Displacement[1+i.connectivity[0]][0],Node_Displacement[1+i.connectivity[0]][1],Node_Displacement[1+i.connectivity[1]][0],Node_Displacement[1+i.connectivity[1]][1],Node_Displacement[1+i.connectivity[2]][0],Node_Displacement[1+i.connectivity[2]][1],Node_Displacement[1+i.connectivity[3]][0],Node_Displacement[1+i.connectivity[3]][1])
        import numpy as np
        Ele_Node_Displacement_Voctor[i.label] = np.array(Ele_Node_Displacement[i.label]).reshape(-1, 1)


    ###创建单元的坐标向量（变形前），Key是单元编号，值是[(coordinates1(x,y,z)),(coordinates2(x,y,z)),(coordinates3(x,y,z)),(coordinates4(x,y,z))]
    Ele_Node_Coordinates = {}
    for i in elmts:
        Ele_Node_Coordinates[i.label] = ((Node_Coordinate[1+i.connectivity[0]]),(Node_Coordinate[1+i.connectivity[1]]),(Node_Coordinate[1+i.connectivity[2]]),(Node_Coordinate[1+i.connectivity[3]]))

    ### 计算单元初始本构矩阵D矩阵
    if Iter == 0:
        for i in elmts:
            E = 145000  # 假设杨氏模量为 210 GPa (典型的钢材料)
            nu = 0.31    # 典型的钢材料泊松比
            # 构造平面应力条件下的应力-应变矩阵 D
            Ele_D0_Matrix[i.label] = (E / (1 - nu**2)) * np.array([[1, nu, 0],[nu, 1, 0],[0, 0, (1 - nu) / 2]])     

    ### 计算单元本构矩阵D矩阵
    Ele_D_Matrix = {}
    for i in elmts:
        E = 145000*(Xe[i.label])**3  # 假设杨氏模量为 210 GPa (典型的钢材料)
        nu = 0.31    # 典型的钢材料泊松比
        # 构造平面应力条件下的应力-应变矩阵 D
        Ele_D_Matrix[i.label] = (E / (1 - nu**2)) * np.array([[1, nu, 0],[nu, 1, 0],[0, 0, (1 - nu) / 2]])            

    ###计算平面四节点单元四个高斯积分点的strian-displacement Matrix B矩阵
    Ele_B_Matrix = {}
    import numpy as np
    from math import sqrt
    def B_Guss(ksi, eta, x1,y1,x2,y2,x3,y3,x4,y4):
        #等参单元局部坐标系下 ksi , eta 
        #节点坐标1.(-1,1) 2.(-1,-1) 3.(1,-1) 4.(1,1),
        #高斯积分点坐标1.(-1/sqrt(3),1/sqrt(3)) 2.(-1/sqrt(3),-1/sqrt(3)) 3.(1/sqrt(3),-1/sqrt(3)) 4.(1/sqrt(3),1/sqrt(3))
        #形函数
        N_1 = ((1-ksi)*(1-eta))/4.0;N_2 = ((1+ksi)*(1-eta))/4.0;N_3 = ((1+ksi)*(1+eta))/4.0;N_4 = ((1-ksi)*(1+eta))/4.0
        #形函数在高斯积分点1.(-1/sqrt(3),1/sqrt(3))的导数：
        N_1_ksi = -0.25*(1-eta);N_1_eta = -0.25*(1-ksi);
        N_2_ksi = 0.25*(1-eta);N_2_eta = -0.25*(1+ksi);
        N_3_ksi = 0.25*(1+eta);N_3_eta = 0.25*(1+ksi);
        N_4_ksi = -0.25*(1+eta);N_4_eta = 0.25*(1-ksi);
        #形函数在高斯积分点1.(-1/sqrt(3),1/sqrt(3))的雅可比矩阵：
        shape_func_deriv_matrix = np.array([
            [N_1_ksi, N_2_ksi, N_3_ksi, N_4_ksi],
            [N_1_eta, N_2_eta, N_3_eta, N_4_eta]])
        node_coord_matrix = np.array([[x1, y1],[x2, y2],[x3, y3],[x4, y4]])
        # 计算雅可比矩阵 J
        J = np.dot(shape_func_deriv_matrix,node_coord_matrix)
        #高斯积分点1.(-1/sqrt(3),1/sqrt(3))的四个应变矩阵Bi
        a = (y1*(ksi-1)+y2*(-1-ksi)+y3*(1+ksi)+y4*(1-ksi))*0.25
        b = (y1*(eta-1)+y2*(1-eta)+y3*(1+eta)+y4*(-1-eta))*0.25
        c = (x1*(eta-1)+x2*(1-eta)+x3*(1+eta)+x4*(-1-eta))*0.25
        d = (x1*(ksi-1)+x2*(-1-ksi)+x3*(1+ksi)+x4*(1-ksi))*0.25
        B_1 = np.array([
            [a * N_1_ksi - b * N_1_eta, 0],
            [0, c * N_1_eta - d * N_1_ksi],
            [c * N_1_eta - d * N_1_ksi, a * N_1_ksi - b * N_1_eta]])
        B_2 = np.array([
            [a * N_2_ksi - b * N_2_eta, 0],
            [0, c * N_2_eta - d * N_2_ksi],
            [c * N_2_eta - d * N_2_ksi, a * N_2_ksi - b * N_2_eta]])    
        B_3 = np.array([
            [a * N_3_ksi - b * N_3_eta, 0],
            [0, c * N_3_eta - d * N_3_ksi],
            [c * N_3_eta - d * N_3_ksi, a * N_3_ksi - b * N_3_eta]])    
        B_4 = np.array([
            [a * N_4_ksi - b * N_4_eta, 0],
            [0, c * N_4_eta - d * N_4_ksi],
            [c * N_4_eta - d * N_4_ksi, a * N_4_ksi - b * N_4_eta]])    
        B_combined = np.hstack([B_1, B_2, B_3, B_4]) / np.linalg.det(J) 
        return B_combined,J
    #每个单元有4个高斯积分点，每个高斯积分点对应一个B矩阵，再加一个质心的高斯积分点(B5)
    Guss_Point = ((-1/sqrt(3),1/sqrt(3)),(-1/sqrt(3),-1/sqrt(3)),(1/sqrt(3),-1/sqrt(3)),(1/sqrt(3),1/sqrt(3)),(0,0))
    for i in elmts:
        x1 , y1 = Ele_Node_Coordinates[i.label][0][0],Ele_Node_Coordinates[i.label][0][1]
        x2 , y2 = Ele_Node_Coordinates[i.label][1][0],Ele_Node_Coordinates[i.label][1][1]
        x3 , y3 = Ele_Node_Coordinates[i.label][2][0],Ele_Node_Coordinates[i.label][2][1]
        x4 , y4 = Ele_Node_Coordinates[i.label][3][0],Ele_Node_Coordinates[i.label][3][1]
        ksi, eta = Guss_Point[0][0], Guss_Point[0][1]
        B1 = B_Guss(ksi, eta, x1,y1,x2,y2,x3,y3,x4,y4)[0]
        J1 = B_Guss(ksi, eta, x1,y1,x2,y2,x3,y3,x4,y4)[1]
        ksi, eta = Guss_Point[1][0], Guss_Point[1][1]
        B2 = B_Guss(ksi, eta, x1,y1,x2,y2,x3,y3,x4,y4)[0]
        J2 = B_Guss(ksi, eta, x1,y1,x2,y2,x3,y3,x4,y4)[1]
        ksi, eta = Guss_Point[2][0], Guss_Point[2][1]
        B3 = B_Guss(ksi, eta, x1,y1,x2,y2,x3,y3,x4,y4)[0]
        J3 = B_Guss(ksi, eta, x1,y1,x2,y2,x3,y3,x4,y4)[1]
        ksi, eta = Guss_Point[3][0], Guss_Point[3][1]
        B4 = B_Guss(ksi, eta, x1,y1,x2,y2,x3,y3,x4,y4)[0]
        J4 = B_Guss(ksi, eta, x1,y1,x2,y2,x3,y3,x4,y4)[1]
        ksi, eta = Guss_Point[4][0], Guss_Point[4][1]
        B5 = B_Guss(ksi, eta, x1,y1,x2,y2,x3,y3,x4,y4)[0]
        J5 = B_Guss(ksi, eta, x1,y1,x2,y2,x3,y3,x4,y4)[1]
        Ele_K_G_Matrix[i.label] = np.linalg.det(J1) * np.linalg.multi_dot([B1.T,Ele_D0_Matrix[i.label],B1]) + np.linalg.det(J2) * np.linalg.multi_dot([B2.T,Ele_D0_Matrix[i.label],B2]) + np.linalg.det(J3) * np.linalg.multi_dot([B3.T,Ele_D0_Matrix[i.label],B3]) + np.linalg.det(J4) * np.linalg.multi_dot([B4.T,Ele_D0_Matrix[i.label],B4])
        Ele_B_Matrix[i.label] = (B1,B2,B3,B4,B5)
    
    #====================提取单元刚度矩阵函数========================================
    def read_StiffnessMatrix(fileName):
        N = 8 # Number of lines of K matrix
        f = open(fileName+'.mtx','r+')
        k = np.zeros((N,N))
        stiffness_matrix = {} #A dictionary with element number and matrix
        line = '*'
        while line:
            #Move index to matrix and read element label
            while line != '*MATRIX,TYPE=STIFFNESS\n':
                line = f.readline()
                if 'ELEMENT NUMBER' in line:
                    element_label = int(re.findall('\d+',line)[0])
            #Read matrix
            x,y = 0,0
            i,j = 0,0
            while i < N:
                i += 1
                j = int((i-1)/4+1)#iteration number for multiple lines
                h = 0 #iteration number for multiple lines
                y = 0#in each iteration, matrix input from y=0
                data = []
                #read next line for over-size data lines
                while h<j:
                    h += 1
                    line = f.readline()
                    split_line = line.strip().split(',')
                    #remove none element in unfully-filled lines
                    if '' in split_line:
                        split_line.remove('')
                    dataLine = [float(s) for s in split_line]
                    data = data + dataLine
                for s in data:
                    k[x,y] = s
                    k[y,x] = k[x,y]
                    y +=1
                x += 1
            stiffness_matrix[element_label] = np.matrix(k)
            line = f.readline()
        #print('Read stiffness matrix well')
        return (stiffness_matrix)

    ###单元K矩阵第一种方法：
    ### 计算初始单元刚度矩阵K
    if Iter == 0:
        for i in elmts:
            Ele_K0_Matrix[i.label] = Ele_K_G_Matrix[i.label]
        
    Line = len(nds)*2

    Ele_L_Matrix = {}
    for i in part.elements:
        Zero_Matrix = np.zeros((8, Line))
        indices = [(1+i.connectivity[0])*2-2, (1+i.connectivity[0])*2-1, (1+i.connectivity[1])*2-2, (1+i.connectivity[1])*2-1, (1+i.connectivity[2])*2-2, (1+i.connectivity[2])*2-1,(1+i.connectivity[3])*2-2, (1+i.connectivity[3])*2-1]
        for j, index in enumerate(indices):
            Zero_Matrix[j, index] = 1
        Ele_L_Matrix[i.label] = Zero_Matrix  
        
        
    #======传热矩阵============================================================================
    def Conductivity_matrix(Coor,k_matrix):
        import math
        from numpy import array as array
        from numpy import zeros as zeros
        from numpy import arange as arange
        from numpy import dot as dot
        from numpy import linalg as linalg

        k = k_matrix  # thermal conductivity
        Dz = 1500.0  # thickness of the slice
        x = Coor  # Coordinates of nodes

        ##
        # Define a little function to calculate the gradient of the basis functions
        # in the parametric coordinates.


        def gradNpar(xi, eta):
            """
            A one-liner to calculate the matrix of the basis function gradients
            in the parametric coordinates.
            """
            return array([
                [eta / 4 - 1. / 4, xi / 4 - 1. / 4],
                [1. / 4 - eta / 4, - xi / 4 - 1. / 4],
                [eta / 4 + 1. / 4, xi / 4 + 1. / 4],
                [- eta / 4 - 1. / 4, 1. / 4 - xi / 4]])

        ##
        # These are the integration point data
        xe = array([[-0.577350269189626, -0.577350269189626],
                    [-0.577350269189626, +0.577350269189626],
                    [+0.577350269189626, -0.577350269189626],
                    [+0.577350269189626, +0.577350269189626]])
        W = array([1, 1, 1, 1])

        ##
        # Initialize the elementwise conductivity matrix.
        Ke = zeros((4, 4))
        ##
        # Loop over the quadrature points.
        for qp in arange(xe.shape[0]):
            xi = xe[qp, 0]
            eta = xe[qp, 1]
            # Compute the Jacobian matrix
            J = dot(x.T, gradNpar(xi, eta))
            # The Jacobian
            detJ = linalg.det(J)
            # The  gradient  of the basis functions with respect to x,y
            gradN = dot(gradNpar(xi, eta), linalg.inv(J))
            # Add the contribution to the conductivity matrix
            Ke = Ke + k * Dz * dot(gradN, gradN.T) * detJ * W[qp]
        return Ke    

    for i in elmts:
        x1 , y1 = Ele_Node_Coordinates[i.label][0][0],Ele_Node_Coordinates[i.label][0][1]
        x2 , y2 = Ele_Node_Coordinates[i.label][1][0],Ele_Node_Coordinates[i.label][1][1]
        x3 , y3 = Ele_Node_Coordinates[i.label][2][0],Ele_Node_Coordinates[i.label][2][1]
        x4 , y4 = Ele_Node_Coordinates[i.label][3][0],Ele_Node_Coordinates[i.label][3][1]
        coor = array([[x1, y1], [x2, y2], [x3, y3], [x4, y4]])
        Ele_K_Thermal_Matrix[i.label] = Conductivity_matrix(coor,0.02*(Xe[i.label])**3) 
        
    #==========================================================================================  
    Temp = []
    for i in seng_TEMP:
        Temp.append(i.data)
    MaxMises = []
    for i in seng_MISES:
        MaxMises.append(i.mises)
    ####2========================================= 
    seng_TEMP = sorted(seng_TEMP, key=lambda x: (x.elementLabel, x.integrationPoint))

    #单元积分点数量N=4,在计算前要确定单元的积分点有多少个！
    #PL = 5.5; #P-norm中的惩罚指数（3-5），越大，越偏向于局部应力，越小越偏向于平均应力
    q = 3
    q_stress= 0.5
    N = 4; MISES = {}; Ae_MISES = {}

    import numpy as np
    N = 4
    for i in range(0,len(seng_TEMP),N):
        TEMP_ele = []
        for j in range(i,i+N):
            TEMP_ele.append(seng_TEMP[j].data)
        vector_TEMP = np.array(TEMP_ele)
        vector_TEMP = vector_TEMP.reshape(-1, 1)
        vector_TEMP_ele[seng_TEMP[i].elementLabel] = vector_TEMP * (Xe[seng_TEMP[i].elementLabel]) ** 3
    
    Ae_COMPLHeat = {}
    for element in elmts:
        result = np.dot(np.dot(vector_TEMP_ele[element.label].T, Ele_K_Thermal_Matrix[element.label]), vector_TEMP_ele[element.label])
        Ae_COMPLHeat[element.label] = (1-0.001) * 3 * Xe[element.label] ** (3-1) * result # 将结果存储在字典中 (1-xmin)*p*Xe^(p-1)*T'KT;
    Ae_COMPLHeat = {key: (value - min(Ae_COMPLHeat.values())) / (max(Ae_COMPLHeat.values()) - min(Ae_COMPLHeat.values())) for key, value in Ae_COMPLHeat.items()}

    MISES_ele = {}; Stress_x_ele = {}; Stress_y_ele = {}; Stress_xy_ele = {}

    Ae_ENERGY = {}  
    for en in seng_ENERGY: 
        Ae_ENERGY[en.elementLabel] = q * en.data/Xe[en.elementLabel]
    Ae_ENERGY = {key: (value - min(Ae_ENERGY.values())) / (max(Ae_ENERGY.values()) - min(Ae_ENERGY.values())) for key, value in Ae_ENERGY.items()}
  
    for element in elmts:
        Ae[element.label] = w3 * Ae_ENERGY[element.label] + w4 * Ae_COMPLHeat[element.label]

    obj_Temp.append(max(Temp))
    obj_Mises.append(max(MaxMises))
    obj_Energy.append(opdb.steps['Step-1'].historyRegions['Assembly ASSEMBLY'].historyOutputs['ALLSE'].data[-1][1])
    obj = w3 * obj_Energy[-1]/obj_Energy[1] + w4 * obj_Temp[-1]/obj_Temp[1]
    opdb.close()
    return obj
      
## Function of preparing filter map (Fm={elm1:[[el1,el2,...],[wf1,wf2,...]],...})##improve speed
def preFlt(Rmin, Elmts, Nds, Fm):
    c0 = {}
    for el in Elmts:
        nds = el.connectivity  # nds为单元的所有节点编号，默认逆时针
        c0[el.label] = np.mean([Nds[nd].coordinates for nd in nds], axis=0)
    # 转换为 NumPy 数组进行向量化计算
    labels = np.array(list(c0.keys()))
    coords = np.array(list(c0.values()))

    for i, el_label in enumerate(labels):
        distances = np.sqrt(np.sum((coords - coords[i]) ** 2, axis=1))
        close_indices = np.where(distances < Rmin)[0]
        close_labels = labels[close_indices]
        weights = Rmin - distances[close_indices]
        weights /= np.sum(weights)
        Fm[el_label] = [close_labels.tolist(), weights.tolist()]
        
## Function of filtering sensitivities
def fltAe(Ae,Fm):
    raw = Ae.copy()
    for el in Fm.keys():
        Ae[el] = 0.0
        for i in range(len(Fm[el][0])): Ae[el]+=raw[Fm[el][0][i]]*Fm[el][1][i]
## Function of optimality update for design variables and Abaqus model
def BESO(Vf,Xe,Ae,Part,Elmts):
    lo, hi = min(Ae.values()), max(Ae.values())
    tv = Vf*len(Elmts)
    while abs((hi-lo)/hi) > 1.0e-5:
        th = (lo+hi)/2.0
        for key in Xe.keys(): Xe[key] = 1.0 if Ae[key]>th else 0.001
        if sum(Xe.values())-tv>0: lo = th
        else: hi = th
    # Label elements as solid or void
    vlb, slb = [], []
    for el in Elmts:
        if Xe[el.label] == 1.0: slb.append(el.label)
        else: vlb.append(el.label)
    # Assign solid and void elements to each section
    Part.SectionAssignment(Part.SetFromElementLabels('ss',slb),'sldSec')
    Part.SectionAssignment(Part.SetFromElementLabels('vs',vlb),'voidSec')
## ====== MAIN PROGRAM ======
if __name__ == '__main__':
    # Set parameters and inputs
    vf, rmin, ert = 0.60, 2.4, 0.02
    
    for w3 in [x * 0.05 for x in range(0,21)]:  # w3 从0到1递增，步长为0.05
        w4 = 1.0 - w3  # w4 = 1.0 - w3
        w2 = 0.0
        folder_path = 'D:/2025_03_22_Fuel rod toplogy/Fuel Rod To/Same heat source/V=0.6 Integrated Topo linear_3/w3='+str(w3)
        os.makedirs(folder_path)        
        # 每次更新w3后重新加载mddb
        mddb = openMdb(pathName='D:/2025_03_22_Fuel rod toplogy/Fuel Rod To/Same heat source/V=0.6 Integrated Topo linear_3/Test.cae') 
        os.chdir(r"D:\2025_03_22_Fuel rod toplogy\Fuel Rod To\Same heat source\V=0.6 Integrated Topo linear_3\w3="+str(w3))
        # Design initialization
        fmtMdb(mddb)  # 确定优化迭代之前有限元模型的设置
        part = mddb.models['Model-1'].parts['Part-1']
        elmts, nds = part.sets['Set-OptDomain'].elements, part.nodes
        oh, vh, obj_Temp, obj_Mises, obj_Energy = [], [], [], [], []  # oh目标函数，vh体积分数
        obj_Temp.append(0); obj_Mises.append(0); obj_Energy.append(0)
        xe, ae, oae, fm = {}, {}, {}, {}  # xe单元密度（设计变量), ae当前单元的灵敏度, oae上一次迭代的单元灵敏度
        Ele_K0_Matrix = {}  # 初始单元刚度矩阵
        Ele_K_G_Matrix = {}
        Ele_D0_Matrix = {}  # 初始单元本构矩阵
        Ele_K_Thermal_Matrix = {}  # 传热刚度矩阵
        vector_TEMP_ele = {}  # 节点温度向量
        PL = 6
        for el in elmts: 
            xe[el.label] = 1.0  # elmts单元集中的所有单元密度为1
        if rmin > 0: 
            preFlt(rmin, elmts, nds, fm)  # 如果过滤半径设置大于0,开启过滤函数
        
        # Optimisation iteration
        change, iter, obj = 1, -1, 0
        while change > 0.01 or vh[-1] > nv:
            iter += 1
            # Run FEA
            oh.append(FEA(iter, mddb, xe, ae, w2, w3, w4))   
            # Process sensitivities
            if rmin > 0: fltAe(ae, fm)
            if iter > 0: ae = dict([(k, (ae[k] + oae[k]) / 2.0) for k in ae.keys()])
            oae = ae.copy()
            # BESO optimisation
            vh.append(sum(xe.values()) / len(xe))
            nv = max(vf, vh[-1] * (1.0 - ert))
            BESO(nv, xe, ae, part, elmts)
            if iter > 10: 
                change = math.fabs((sum(oh[iter - 3: iter + 1]) - sum(oh[iter - 7: iter - 3])) / sum(oh[iter - 7: iter - 3]))
        
        # Save results
        mddb.customData.History = {'vol': vh, 'obj': oh, 'obj_Temp': obj_Temp, 'obj_Mises': obj_Mises, 'obj_Energy': obj_Energy}
        mddb.saveAs(pathName='D:/2025_03_22_Fuel rod toplogy/Fuel Rod To/Same heat source/V=0.6 Integrated Topo linear_3/w3='+str(w3)+'/Final_design.cae')
        # 获取所有文件，查找最大数字的 Design_JobXX.inp 文件
        max_xx = -1
        max_file = None

        # 正则表达式，匹配文件名中的 Design_Job 和后面的数字部分
        pattern = r"Design_Job(\d+)\.inp"

        # 遍历文件夹中的所有文件
        for filename in os.listdir(folder_path):
            match = re.match(pattern, filename)  # 使用正则表达式匹配文件名
            if match:
                # 提取数字部分
                xx = int(match.group(1))  # group(1) 是匹配的数字部分
                if xx > max_xx:
                    max_xx = xx
                    max_file = filename
        ModelName = 'Design_Job'+str(max_xx)
        Mdb()
        mdb.ModelFromInputFile(name=ModelName, inputFileName='D:/2025_03_22_Fuel rod toplogy/Fuel Rod To/Same heat source/V=0.6 Integrated Topo linear_3/w3='+str(w3)+'/Design_Job'+str(max_xx)+'.inp')

        source_file = 'D:/2025_03_22_Fuel rod toplogy/Fuel Rod To/Same heat source/V=0.6 Integrated Topo linear_3/JiaoHe.py'  # A 文件夹中的文件
        destination_folder = 'D:/2025_03_22_Fuel rod toplogy/Fuel Rod To/Same heat source/V=0.6 Integrated Topo linear_3/w3='+str(w3)  # B 文件夹路径
        shutil.copy(source_file, destination_folder)
        JiaoHe(ModelName)
        
        p = mdb.models['Design_Job'+str(max_xx)].parts['PART-1']
        e = p.elements
        elements = e.getSequenceFromMask(mask=('[#ffffffff:653 #1ffffff ]', ), )
        p.Set(elements=elements, name='ALL')        
        userSubroutineName = 'D:\\2025_03_22_Fuel rod toplogy\\Fuel Rod To\\Same heat source\\V=0.6 Integrated Topo linear_3\\Userdefine_GAPCON_CREEP_3.for'
        
        mdb.Job(name='Job-1', model=ModelName, description='', type=ANALYSIS, 
            atTime=None, waitMinutes=0, waitHours=0, queue=None, memory=90, 
            memoryUnits=PERCENTAGE, getMemoryFromAnalysis=True, 
            explicitPrecision=SINGLE, nodalOutputPrecision=SINGLE, echoPrint=OFF, 
            modelPrint=OFF, contactPrint=OFF, historyPrint=OFF, 
            userSubroutine = userSubroutineName, 
            scratch='', resultsFormat=ODB, multiprocessingMode=DEFAULT, numCpus=8, 
            numDomains=8, numGPUs=0)            

        mdb.jobs['Job-1'].submit(consistencyChecking=OFF)
        mdb.jobs['Job-1'].waitForCompletion()            
        source_file = 'D:/2025_03_22_Fuel rod toplogy/Fuel Rod To/Same heat source/V=0.6 Integrated Topo linear_3/IsoSmooth.py'  # A 文件夹中的文件
        destination_folder = 'D:/2025_03_22_Fuel rod toplogy/Fuel Rod To/Same heat source/V=0.6 Integrated Topo linear_3/w3='+str(w3)  # B 文件夹路径
        shutil.copy(source_file, destination_folder)         
        IsoSmooth('Job-1.odb')



                
                
