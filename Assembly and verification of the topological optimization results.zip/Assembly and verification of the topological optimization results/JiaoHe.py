#! /user/bin/python
#-*-coding: UTF-8-*-
# -*- coding: mbcs -*-
"""code by Hao Jin"""
from abaqus import *
from abaqusConstants import *
from abaqus import getInput,getInputs
from odbAccess import openOdb
from job import *
import numpy as np
import mmap
import regionToolset
import load
import math,customKernel
import mesh

def JiaoHe(ModelName):

    mdb.models[ModelName].materials['MATERIAL01'].conductivity.setValues(
        temperatureDependency=ON, table=((11.44796, 200.0), (12.6416875, 250.0), (
        13.79891, 300.0), (14.9196275, 350.0), (16.00384, 400.0), (17.0515475, 
        450.0), (18.06275, 500.0), (19.0374475, 550.0), (19.97564, 600.0), (
        20.8773275, 650.0), (21.74251, 700.0), (22.5711875, 750.0), (23.36336, 
        800.0), (24.1190275, 850.0), (24.83819, 900.0), (25.5208475, 950.0), (
        26.167, 1000.0), (26.7766475, 1050.0), (27.34979, 1100.0), (27.8864275, 
        1150.0), (28.38656, 1200.0), (28.8501875, 1250.0), (29.27731, 1300.0), (
        29.6679275, 1350.0), (30.02204, 1400.0), (30.3396475, 1450.0), (30.62075, 
        1500.0)))
    mdb.models[ModelName].materials['MATERIAL01'].density.setValues(
        temperatureDependency=ON, table=((7.99826e-09, 200.0), (7.97634e-09, 
        250.0), (7.95423e-09, 300.0), (7.93191e-09, 350.0), (7.90941e-09, 400.0), (
        7.88671e-09, 450.0), (7.86382e-09, 500.0), (7.84073e-09, 550.0), (
        7.81744e-09, 600.0), (7.79396e-09, 650.0), (7.77029e-09, 700.0), (
        7.74642e-09, 750.0), (7.72236e-09, 800.0), (7.6981e-09, 850.0), (
        7.67365e-09, 900.0), (7.649e-09, 950.0), (7.62416e-09, 1000.0), (
        7.59912e-09, 1050.0), (7.57389e-09, 1100.0), (7.54847e-09, 1150.0), (
        7.52285e-09, 1200.0), (7.49703e-09, 1250.0), (7.47102e-09, 1300.0), (
        7.44482e-09, 1350.0), (7.41842e-09, 1400.0), (7.39182e-09, 1450.0), (
        7.36504e-09, 1500.0)))
    mdb.models[ModelName].materials['MATERIAL01'].elastic.setValues(
        temperatureDependency=ON, table=((200530.546, 0.31, 200.0), (196676.6825, 
        0.31, 250.0), (192822.819, 0.31, 300.0), (188968.9555, 0.31, 350.0), (
        185115.092, 0.31, 400.0), (181261.2285, 0.31, 450.0), (177407.365, 0.31, 
        500.0), (173553.5015, 0.31, 550.0), (169699.638, 0.31, 600.0), (
        165845.7745, 0.31, 650.0), (161991.911, 0.31, 700.0), (158138.0475, 0.31, 
        750.0), (154284.184, 0.31, 800.0), (150430.3205, 0.31, 850.0), (146576.457, 
        0.31, 900.0), (142722.5935, 0.31, 950.0), (138868.73, 0.31, 1000.0), (
        135014.8665, 0.31, 1050.0), (131161.003, 0.31, 1100.0), (127307.1395, 0.31, 
        1150.0), (123453.276, 0.31, 1200.0), (119599.4125, 0.31, 1250.0), (
        115745.549, 0.31, 1300.0), (111891.6855, 0.31, 1350.0), (108037.822, 0.31, 
        1400.0), (104183.9585, 0.31, 1450.0), (100330.095, 0.31, 1500.0)))
    mdb.models[ModelName].materials['MATERIAL01'].expansion.setValues(
        table=((1.83827e-05, 200.0), (1.85099e-05, 250.0), (1.86388e-05, 300.0), (
        1.87693e-05, 350.0), (1.89015e-05, 400.0), (1.90353e-05, 450.0), (
        1.91707e-05, 500.0), (1.93078e-05, 550.0), (1.94465e-05, 600.0), (
        1.95868e-05, 650.0), (1.97288e-05, 700.0), (1.98724e-05, 750.0), (
        2.00176e-05, 800.0), (2.01645e-05, 850.0), (2.0313e-05, 900.0), (
        2.04631e-05, 950.0), (2.06149e-05, 1000.0), (2.07683e-05, 1050.0), (
        2.09233e-05, 1100.0), (2.108e-05, 1150.0), (2.12383e-05, 1200.0), (
        2.13983e-05, 1250.0), (2.15599e-05, 1300.0), (2.17231e-05, 1350.0), (
        2.18879e-05, 1400.0), (2.20544e-05, 1450.0), (2.22225e-05, 1500.0)), 
        temperatureDependency=ON)
    mdb.models[ModelName].materials['MATERIAL01'].SpecificHeat(
        temperatureDependency=ON, table=((464780000.0, 200.0), (473860000.0, 
        250.0), (482940000.0, 300.0), (492020000.0, 350.0), (501100000.0, 400.0), (
        510180000.0, 450.0), (519260000.0, 500.0), (528340000.0, 550.0), (
        537420000.0, 600.0), (546500000.0, 650.0), (555580000.0, 700.0), (
        564660000.0, 750.0), (573740000.0, 800.0), (582820000.0, 850.0), (
        591900000.0, 900.0), (600980000.0, 950.0), (610060000.0, 1000.0), (
        619140000.0, 1050.0), (628220000.0, 1100.0), (637300000.0, 1150.0), (
        646380000.0, 1200.0), (655460000.0, 1250.0), (664540000.0, 1300.0), (
        673620000.0, 1350.0), (682700000.0, 1400.0), (691780000.0, 1450.0), (
        700860000.0, 1500.0)))
    mdb.models[ModelName].materials['MATERIAL01'].Creep(law=USER, table=())
    mdb.models[ModelName].materials['MATERIAL01'].Depvar(n=2)

    del mdb.models[ModelName].materials['MATERIAL02']
    mdb.models[ModelName].Material(name='MATERIAL02', objectToCopy=mdb.models[ModelName].materials['MATERIAL01'])
        
    mdb.models[ModelName].materials['MATERIAL02'].conductivity.setValues(
        temperatureDependency=ON, table=((11.44796e-10, 200.0), (12.6416875e-10, 250.0), (
        13.79891e-10, 300.0), (14.9196275e-10, 350.0), (16.00384e-10, 400.0), (17.0515475e-10, 
        450.0), (18.06275e-10, 500.0), (19.0374475e-10, 550.0), (19.97564e-10, 600.0), (
        20.8773275e-10, 650.0), (21.74251e-10, 700.0), (22.5711875e-10, 750.0), (23.36336e-10, 
        800.0), (24.1190275e-10, 850.0), (24.83819e-10, 900.0), (25.5208475e-10, 950.0), (
        26.167e-10, 1000.0), (26.7766475e-10, 1050.0), (27.34979e-10, 1100.0), (27.8864275e-10, 
        1150.0), (28.38656e-10, 1200.0), (28.8501875e-10, 1250.0), (29.27731e-10, 1300.0), (
        29.6679275e-10, 1350.0), (30.02204e-10, 1400.0), (30.3396475e-10, 1450.0), (30.62075e-10, 
        1500.0)))
    mdb.models[ModelName].materials['MATERIAL02'].density.setValues(
        temperatureDependency=ON, table=((7.99826e-19, 200.0), (7.97634e-19, 
        250.0), (7.95423e-19, 300.0), (7.93191e-19, 350.0), (7.90941e-19, 400.0), (
        7.88671e-19, 450.0), (7.86382e-19, 500.0), (7.84073e-19, 550.0), (
        7.81744e-19, 600.0), (7.79396e-19, 650.0), (7.77029e-19, 700.0), (
        7.74642e-19, 750.0), (7.72236e-19, 800.0), (7.6981e-19, 850.0), (
        7.67365e-19, 900.0), (7.649e-19, 950.0), (7.62416e-19, 1000.0), (
        7.59912e-19, 1050.0), (7.57389e-19, 1100.0), (7.54847e-19, 1150.0), (
        7.52285e-19, 1200.0), (7.49703e-19, 1250.0), (7.47102e-19, 1300.0), (
        7.44482e-19, 1350.0), (7.41842e-19, 1400.0), (7.39182e-19, 1450.0), (
        7.36504e-19, 1500.0)))
    mdb.models[ModelName].materials['MATERIAL02'].elastic.setValues(
        temperatureDependency=ON, table=((200530.546e-10, 0.31, 200.0), (196676.6825e-10, 
        0.31, 250.0), (192822.819e-10, 0.31, 300.0), (188968.9555e-10, 0.31, 350.0), (
        185115.092e-10, 0.31, 400.0), (181261.2285e-10, 0.31, 450.0), (177407.365e-10, 0.31, 
        500.0), (173553.5015e-10, 0.31, 550.0), (169699.638e-10, 0.31, 600.0), (
        165845.7745e-10, 0.31, 650.0), (161991.911e-10, 0.31, 700.0), (158138.0475e-10, 0.31, 
        750.0), (154284.184e-10, 0.31, 800.0), (150430.3205e-10, 0.31, 850.0), (146576.457e-10, 
        0.31, 900.0), (142722.5935e-10, 0.31, 950.0), (138868.73e-10, 0.31, 1000.0), (
        135014.8665e-10, 0.31, 1050.0), (131161.003e-10, 0.31, 1100.0), (127307.1395e-10, 0.31, 
        1150.0), (123453.276e-10, 0.31, 1200.0), (119599.4125e-10, 0.31, 1250.0), (
        115745.549e-10, 0.31, 1300.0), (111891.6855e-10, 0.31, 1350.0), (108037.822e-10, 0.31, 
        1400.0), (104183.9585e-10, 0.31, 1450.0), (100330.095e-10, 0.31, 1500.0)))
    mdb.models[ModelName].materials['MATERIAL02'].expansion.setValues(
        table=((1.83827e-15, 200.0), (1.85099e-15, 250.0), (1.86388e-15, 300.0), (
        1.87693e-15, 350.0), (1.89015e-15, 400.0), (1.90353e-15, 450.0), (
        1.91707e-15, 500.0), (1.93078e-15, 550.0), (1.94465e-15, 600.0), (
        1.95868e-15, 650.0), (1.97288e-15, 700.0), (1.98724e-15, 750.0), (
        2.00176e-15, 800.0), (2.01645e-15, 850.0), (2.0313e-15, 900.0), (
        2.04631e-15, 950.0), (2.06149e-15, 1000.0), (2.07683e-15, 1050.0), (
        2.09233e-15, 1100.0), (2.108e-15, 1150.0), (2.12383e-15, 1200.0), (
        2.13983e-15, 1250.0), (2.15599e-15, 1300.0), (2.17231e-15, 1350.0), (
        2.18879e-15, 1400.0), (2.20544e-15, 1450.0), (2.22225e-15, 1500.0)), 
        temperatureDependency=ON)
    mdb.models[ModelName].materials['MATERIAL02'].SpecificHeat(
        temperatureDependency=ON, table=((464780000.0, 200.0), (473860000.0, 
        250.0), (482940000.0, 300.0), (492020000.0, 350.0), (501100000.0, 400.0), (
        510180000.0, 450.0), (519260000.0, 500.0), (528340000.0, 550.0), (
        537420000.0, 600.0), (546500000.0, 650.0), (555580000.0, 700.0), (
        564660000.0, 750.0), (573740000.0, 800.0), (582820000.0, 850.0), (
        591900000.0, 900.0), (600980000.0, 950.0), (610060000.0, 1000.0), (
        619140000.0, 1050.0), (628220000.0, 1100.0), (637300000.0, 1150.0), (
        646380000.0, 1200.0), (655460000.0, 1250.0), (664540000.0, 1300.0), (
        673620000.0, 1350.0), (682700000.0, 1400.0), (691780000.0, 1450.0), (
        700860000.0, 1500.0)))
    mdb.models[ModelName].materials['MATERIAL02'].Creep(law=USER, table=())
    mdb.models[ModelName].materials['MATERIAL02'].Depvar(n=2)
        
    mdb.models[ModelName].Material(name='MATERIAL-UO2')
    mdb.models[ModelName].materials['MATERIAL-UO2'].Conductivity(
        temperatureDependency=ON, table=((10.6094, 200.0), (10.6097, 250.0), (
        10.6104, 300.0), (10.6117, 350.0), (10.6141, 400.0), (10.6185, 450.0), (
        10.6267, 500.0), (10.6419, 550.0), (10.6699, 600.0), (10.7206, 650.0), (
        10.8102, 700.0), (10.9616, 750.0), (11.1996, 800.0), (11.5337, 850.0), (
        11.9352, 900.0), (12.3367, 950.0), (12.6708, 1000.0), (12.909, 1050.0), (
        13.0607, 1100.0), (13.1505, 1150.0), (13.2015, 1200.0), (13.2298, 1250.0), 
        (13.2453, 1300.0), (13.2537, 1350.0), (13.2583, 1400.0), (13.2608, 1450.0), 
        (13.2621, 1500.0), (13.2629, 1550.0), (13.2632, 1600.0), (13.2635, 1650.0), 
        (13.2636, 1700.0), (13.2636, 1750.0), (13.2637, 1800.0), (13.2637, 1850.0), 
        (13.2637, 1900.0), (13.2637, 1950.0), (13.2637, 2000.0)))
    mdb.models[ModelName].materials['MATERIAL-UO2'].Creep(law=USER, 
        table=())
    mdb.models[ModelName].materials['MATERIAL-UO2'].Density(table=((
        1.052e-08, ), ))
    mdb.models[ModelName].materials['MATERIAL-UO2'].Depvar(n=2)
    mdb.models[ModelName].materials['MATERIAL-UO2'].Elastic(
        temperatureDependency=ON, table=((196890.1268, 0.316, 200.0), (195791.6185, 
        0.316, 250.0), (194693.1102, 0.316, 300.0), (193594.6019, 0.316, 350.0), (
        192496.0936, 0.316, 400.0), (191397.5853, 0.316, 450.0), (190299.077, 
        0.316, 500.0), (189200.5687, 0.316, 550.0), (188102.0604, 0.316, 600.0), (
        187003.5521, 0.316, 650.0), (185905.0438, 0.316, 700.0), (184806.5355, 
        0.316, 750.0), (183708.0271, 0.316, 800.0), (182609.5188, 0.316, 850.0), (
        181511.0105, 0.316, 900.0), (180412.5022, 0.316, 950.0), (179313.9939, 
        0.316, 1000.0), (178215.4856, 0.316, 1050.0), (177116.9773, 0.316, 1100.0), 
        (176018.469, 0.316, 1150.0), (174919.9607, 0.316, 1200.0), (173821.4524, 
        0.316, 1250.0), (172722.9441, 0.316, 1300.0), (171624.4358, 0.316, 1350.0), 
        (170525.9275, 0.316, 1400.0), (169427.4192, 0.316, 1450.0), (168328.9109, 
        0.316, 1500.0)))
    mdb.models[ModelName].materials['MATERIAL-UO2'].Expansion(table=((
        9.20526e-06, 200.0), (9.2031e-06, 250.0), (9.20753e-06, 300.0), (
        9.21852e-06, 350.0), (9.23608e-06, 400.0), (9.26017e-06, 450.0), (
        9.2908e-06, 500.0), (9.32795e-06, 550.0), (9.3716e-06, 600.0), (
        9.42175e-06, 650.0), (9.47837e-06, 700.0), (9.54146e-06, 750.0), (
        9.611e-06, 800.0), (9.68698e-06, 850.0), (9.76939e-06, 900.0), (
        9.80945e-06, 923.0), (1.03194e-05, 950.0), (1.04218e-05, 1000.0), (
        1.05419e-05, 1050.0), (1.06799e-05, 1100.0), (1.08357e-05, 1150.0), (
        1.10092e-05, 1200.0), (1.12004e-05, 1250.0), (1.14092e-05, 1300.0), (
        1.16356e-05, 1350.0), (1.18795e-05, 1400.0), (1.21409e-05, 1450.0), (
        1.24198e-05, 1500.0), (1.27161e-05, 1550.0), (1.30297e-05, 1600.0), (
        1.33606e-05, 1650.0), (1.37088e-05, 1700.0), (1.40742e-05, 1750.0), (
        1.44568e-05, 1800.0), (1.48565e-05, 1850.0), (1.52733e-05, 1900.0), (
        1.57072e-05, 1950.0), (1.6158e-05, 2000.0)), temperatureDependency=ON)
    mdb.models[ModelName].materials['MATERIAL-UO2'].SpecificHeat(
        temperatureDependency=ON, table=((9.20526e-06, 200.0), (9.2031e-06, 250.0), 
        (9.20753e-06, 300.0), (9.21852e-06, 350.0), (9.23608e-06, 400.0), (
        9.26017e-06, 450.0), (9.2908e-06, 500.0), (9.32795e-06, 550.0), (
        9.3716e-06, 600.0), (9.42175e-06, 650.0), (9.47837e-06, 700.0), (
        9.54146e-06, 750.0), (9.611e-06, 800.0), (9.68698e-06, 850.0), (
        9.76939e-06, 900.0), (9.80945e-06, 923.0), (1.03194e-05, 950.0), (
        1.04218e-05, 1000.0), (1.05419e-05, 1050.0), (1.06799e-05, 1100.0), (
        1.08357e-05, 1150.0), (1.10092e-05, 1200.0), (1.12004e-05, 1250.0), (
        1.14092e-05, 1300.0), (1.16356e-05, 1350.0), (1.18795e-05, 1400.0), (
        1.21409e-05, 1450.0), (1.24198e-05, 1500.0), (1.27161e-05, 1550.0), (
        1.30297e-05, 1600.0), (1.33606e-05, 1650.0), (1.37088e-05, 1700.0), (
        1.40742e-05, 1750.0), (1.44568e-05, 1800.0), (1.48565e-05, 1850.0), (
        1.52733e-05, 1900.0), (1.57072e-05, 1950.0), (1.6158e-05, 2000.0)))
    mdb.models[ModelName].materials['MATERIAL-UO2'].Swelling(law=USER, 
        table=())
        
    s1 = mdb.models[ModelName].ConstrainedSketch(name='__profile__', 
        sheetSize=200.0)
    g, v, d, c = s1.geometry, s1.vertices, s1.dimensions, s1.constraints
    s1.setPrimaryObject(option=STANDALONE)
    s1.Spot(point=(31.5, -90.932667))
    s1.Spot(point=(31.5, -127.305734))
    s1.Spot(point=(0.0, -145.492268))
    s1.Spot(point=(0.0, -109.119201))
    s1.Spot(point=(0.0, -72.746134))
    s1.Spot(point=(0.0, -36.373067))
    s1.Spot(point=(31.5, -54.5596))
    s1.Spot(point=(63.0, -109.119201))

    s1.CircleByCenterPerimeter(center=(0.0, -36.373067), point1=(8.75, -20.0))
    s1.RadialDimension(curve=g[2], textPoint=(37.2307281494141, -15.1576461791992), 
        radius=5.9)
    s1.CircleByCenterPerimeter(center=(0.0, -36.373067), point1=(11.25, -35.0))
    s1.RadialDimension(curve=g[3], textPoint=(30.31982421875, -37.8897171020508), 
        radius=6.9)

    s1.CircleByCenterPerimeter(center=(31.5, -54.5596), point1=(38.75, -58.75))
    s1.RadialDimension(curve=g[4], textPoint=(54.3858489990234, -49.1492462158203), 
        radius=6.9)

    s1.CircleByCenterPerimeter(center=(31.5, -54.5596), point1=(36.1438511082394, 
        -59.6629956229656))
    s1.CoincidentConstraint(entity1=v[15], entity2=g[4], addUndoState=False)
    s1.undo()

    s1.CircleByCenterPerimeter(center=(31.5, -54.5596), point1=(33.75, -56.25))
    s1.RadialDimension(curve=g[5], textPoint=(46.4640693664551, -55.8605537414551), 
        radius=5.9)

    s1.CircleByCenterPerimeter(center=(0.0, -72.746134), point1=(6.25, -76.25))
    s1.RadialDimension(curve=g[6], textPoint=(13.2549057006836, -72.8071899414063), 
        radius=5.9)
    s1.CircleByCenterPerimeter(center=(0.0, -72.746134), point1=(8.75, -82.5))
    s1.RadialDimension(curve=g[7], textPoint=(26.1747741699219, -79.6139297485352), 
        radius=6.9)

    s1.CircleByCenterPerimeter(center=(31.5, -90.932667), point1=(37.5, -96.25))
    s1.RadialDimension(curve=g[8], textPoint=(52.5089416503906, -90.3742218017578), 
        radius=5.9)
    s1.CircleByCenterPerimeter(center=(31.5, -90.932667), point1=(52.5, -91.25))
    s1.RadialDimension(curve=g[9], textPoint=(59.354118347168, -79.3426132202148), 
        radius=6.9)

    s1.CircleByCenterPerimeter(center=(0.0, -109.119201), point1=(3.75, -112.5))
    s1.RadialDimension(curve=g[10], textPoint=(11.6557388305664, 
        -108.536819458008), radius=5.9)
    s1.CircleByCenterPerimeter(center=(0.0, -109.119201), point1=(8.75, -116.25))
    s1.RadialDimension(curve=g[11], textPoint=(17.1188049316406, 
        -102.298400878906), radius=6.9)
    s1.CircleByCenterPerimeter(center=(63.0, -109.119201), point1=(67.5, -112.5))
    s1.RadialDimension(curve=g[12], textPoint=(76.4321746826172, 
        -108.341865539551), radius=5.9)
    s1.CircleByCenterPerimeter(center=(63.0, -109.119201), point1=(71.25, -117.5))
    s1.RadialDimension(curve=g[13], textPoint=(81.8952484130859, 
        -115.555038452148), radius=6.9)
    s1.CircleByCenterPerimeter(center=(31.5, -127.305734), point1=(37.5, -132.5))
    s1.RadialDimension(curve=g[14], textPoint=(51.458122253418, -128.811676025391), 
        radius=5.9)
    s1.CircleByCenterPerimeter(center=(31.5, -127.305734), point1=(47.5, -138.75))
    s1.RadialDimension(curve=g[15], textPoint=(64.9207000732422, 
        -127.641975402832), radius=6.9)

    s1.CircleByCenterPerimeter(center=(0.0, -145.492268), point1=(6.25, -150.0))
    s1.RadialDimension(curve=g[16], textPoint=(18.6324806213379, 
        -147.163269042969), radius=5.9)
    s1.CircleByCenterPerimeter(center=(0.0, -145.492268), point1=(8.75, -151.25))
    s1.RadialDimension(curve=g[17], textPoint=(16.3320350646973, -142.27880859375), 
        radius=6.9)

    p = mdb.models[ModelName].Part(name='Part-2', 
        dimensionality=TWO_D_PLANAR, type=DEFORMABLE_BODY)
    p = mdb.models[ModelName].parts['Part-2']
    p.BaseShell(sketch=s1)
    s1.unsetPrimaryObject()
    p = mdb.models[ModelName].parts['Part-2']
    session.viewports['Viewport: 1'].setValues(displayedObject=p)
    del mdb.models[ModelName].sketches['__profile__']

    s = mdb.models[ModelName].ConstrainedSketch(name='__profile__', 
        sheetSize=200.0)
    g, v, d, c = s.geometry, s.vertices, s.dimensions, s.constraints
    s.setPrimaryObject(option=STANDALONE)
    s.Spot(point=(10.5, -54.5596))

    s.Spot(point=(10.5, -90.932667))

    s.Spot(point=(21.0, -109.119201))
    s.Spot(point=(42.0, -109.119201))
    s.Spot(point=(10.5, -127.305734))
    s.Spot(point=(21.0, -72.746134))
    s.Spot(point=(10.5, -18.186533))
    s.Spot(point=(21.0, -36.373067))
    s.Spot(point=(42.0, -72.746134))
    s.Spot(point=(52.5, -90.932667))

    s.CircleByCenterPerimeter(center=(10.5, -18.186533), point1=(16.25, -22.5))
    s.CircleByCenterPerimeter(center=(21.0, -36.373067), point1=(28.75, -38.75))
    s.CircleByCenterPerimeter(center=(10.5, -54.5596), point1=(17.5, -57.5))
    s.CircleByCenterPerimeter(center=(21.0, -72.746134), point1=(27.5, -80.0))
    s.CircleByCenterPerimeter(center=(42.0, -72.746134), point1=(43.75, -80.0))
    s.CircleByCenterPerimeter(center=(10.5, -90.932667), point1=(17.5, -93.75))
    s.CircleByCenterPerimeter(center=(52.5, -90.932667), point1=(58.75, -93.75))
    s.CircleByCenterPerimeter(center=(42.0, -109.119201), point1=(48.75, -108.75))
    s.CircleByCenterPerimeter(center=(21.0, -109.119201), point1=(12.5, -110.0))
    s.RadialDimension(curve=g[2], textPoint=(38.7872695922852, -14.9260272979736), 
        radius=4.8)
    s.RadialDimension(curve=g[3], textPoint=(45.6519088745117, -33.8700103759766), 
        radius=4.8)

    s.RadialDimension(curve=g[4], textPoint=(24.1250076293945, -50.6427001953125), 
        radius=4.8)
    s.RadialDimension(curve=g[6], textPoint=(56.7160110473633, -63.7433319091797), 
        radius=4.8)
    s.RadialDimension(curve=g[5], textPoint=(34.4267654418945, -64.6790924072266), 
        radius=4.8)

    s.RadialDimension(curve=g[8], textPoint=(71.4910507202148, -89.3832855224609), 
        radius=4.8)
    s.RadialDimension(curve=g[7], textPoint=(21.9907836914063, -88.3234252929688), 
        radius=4.8)
    s.RadialDimension(curve=g[9], textPoint=(56.817756652832, -106.694244384766), 
        radius=4.8)
    s.RadialDimension(curve=g[10], textPoint=(33.3051300048828, -102.101539611816), 
        radius=4.8)

    s.CircleByCenterPerimeter(center=(10.5, -127.305734), point1=(17.5, -135.0))
    s.RadialDimension(curve=g[11], textPoint=(40.7997283935547, -137.364181518555), 
        radius=4.8)

    s.CircleByCenterPerimeter(center=(10.5, -18.186533), point1=(16.25, -23.75))
    s.CircleByCenterPerimeter(center=(10.5, -18.186533), point1=(18.75, -25.0))
    s.RadialDimension(curve=g[12], textPoint=(25.010082244873, -21.1787719726563), 
        radius=4.9)
    s.RadialDimension(curve=g[13], textPoint=(24.9014358520508, -24.8697624206543), 
        radius=5.9)

    s.CircleByCenterPerimeter(center=(21.0, -36.373067), point1=(28.75, -40.0))
    s.CircleByCenterPerimeter(center=(21.0, -36.373067), point1=(31.25, -43.75))
    s.RadialDimension(curve=g[14], textPoint=(39.6049118041992, -40.4778747558594), 
        radius=4.9)
    s.RadialDimension(curve=g[15], textPoint=(43.5881118774414, -38.6122779846191), 
        radius=5.9)

    s.CircleByCenterPerimeter(center=(10.5, -54.5596), point1=(16.25, -58.75))
    s.CircleByCenterPerimeter(center=(10.5, -54.5596), point1=(17.5, -60.0))
    s.RadialDimension(curve=g[16], textPoint=(21.7763729095459, -56.5416488647461), 
        radius=4.9)
    s.RadialDimension(curve=g[17], textPoint=(22.1208019256592, -59.147331237793), 
        radius=5.9)

    s.CircleByCenterPerimeter(center=(21.0, -72.746134), point1=(26.25, -76.25))
    s.CircleByCenterPerimeter(center=(21.0, -72.746134), point1=(26.7038669586182, 
        -78.234260559082))
    s.RadialDimension(curve=g[18], textPoint=(31.7342853546143, -74.100471496582), 
        radius=4.9)
    s.RadialDimension(curve=g[19], textPoint=(30.7940216064453, -76.7310638427734), 
        radius=5.9)

    s.CircleByCenterPerimeter(center=(42.0, -72.746134), point1=(47.5, -76.25))
    s.CircleByCenterPerimeter(center=(42.0, -72.746134), point1=(48.75, -78.75))
    s.RadialDimension(curve=g[20], textPoint=(53.5962524414063, -72.5643005371094), 
        radius=4.9)
    s.RadialDimension(curve=g[21], textPoint=(53.1928596496582, -76.2926483154297), 
        radius=5.9)

    s.CircleByCenterPerimeter(center=(10.5, -90.932667), point1=(16.25, -95.0))
    s.CircleByCenterPerimeter(center=(10.5, -90.932667), point1=(17.5, -97.5))
    s.RadialDimension(curve=g[22], textPoint=(24.8708839416504, -92.8708724975586), 
        radius=4.9)
    s.RadialDimension(curve=g[23], textPoint=(24.3780097961426, -97.5845260620117), 
        radius=5.9)

    s.CircleByCenterPerimeter(center=(52.5, -90.932667), point1=(58.75, -95.0))
    s.CircleByCenterPerimeter(center=(52.5, -90.932667), point1=(60.0, -97.5))
    s.RadialDimension(curve=g[24], textPoint=(66.8941421508789, -95.2639923095703), 
        radius=4.9)
    s.RadialDimension(curve=g[25], textPoint=(65.832160949707, -92.9545135498047), 
        radius=5.9)

    s.CircleByCenterPerimeter(center=(21.0, -109.119201), point1=(26.1827831268311, 
        -113.051170349121))
    s.CircleByCenterPerimeter(center=(21.0, -109.119201), point1=(26.8318634033203, 
        -114.867111206055))
    s.RadialDimension(curve=g[26], textPoint=(31.1157894134521, -108.857215881348), 
        radius=4.9)
    s.RadialDimension(curve=g[27], textPoint=(31.7215976715088, -111.191993713379), 
        radius=5.9)

    s.CircleByCenterPerimeter(center=(42.0, -109.119201), point1=(47.5, -113.75))
    s.CircleByCenterPerimeter(center=(42.0, -109.119201), point1=(48.75, -115.0))
    s.RadialDimension(curve=g[28], textPoint=(55.9177360534668, -112.196342468262), 
        radius=4.9)
    s.RadialDimension(curve=g[29], textPoint=(56.4077110290527, -109.911666870117), 
        radius=5.9)

    s.CircleByCenterPerimeter(center=(10.5, -127.305734), point1=(17.5, -130.0))
    s.CircleByCenterPerimeter(center=(10.5, -127.305734), point1=(18.75, -133.75))
    s.RadialDimension(curve=g[30], textPoint=(24.1131858825684, -126.806869506836), 
        radius=4.9)
    s.RadialDimension(curve=g[31], textPoint=(23.2589454650879, -125.153121948242), 
        radius=5.9)

    p = mdb.models[ModelName].Part(name='Part-3', 
        dimensionality=TWO_D_PLANAR, type=DEFORMABLE_BODY)
    p = mdb.models[ModelName].parts['Part-3']
    p.BaseShell(sketch=s)
    s.unsetPrimaryObject()
    p = mdb.models[ModelName].parts['Part-3']
    session.viewports['Viewport: 1'].setValues(displayedObject=p)
    del mdb.models[ModelName].sketches['__profile__']

    p = mdb.models[ModelName].parts['Part-2']
    s = p.features['Shell planar-1'].sketch
    mdb.models[ModelName].ConstrainedSketch(name='__edit__', 
        objectToCopy=s)
    s2 = mdb.models[ModelName].sketches['__edit__']
    g, v, d, c = s2.geometry, s2.vertices, s2.dimensions, s2.constraints
    s2.setPrimaryObject(option=SUPERIMPOSE)
    p.projectReferencesOntoSketch(sketch=s2, 
        upToFeature=p.features['Shell planar-1'], filter=COPLANAR_EDGES)

    s2.CircleByCenterPerimeter(center=(0.0, 0.0), point1=(-12.5, -1.25))
    s2.CircleByCenterPerimeter(center=(0.0, 0.0), point1=(18.75, -10.0))
    s2.RadialDimension(curve=g[18], textPoint=(42.3156585693359, 2.25788497924805), 
        radius=5.9)
    s2.RadialDimension(curve=g[19], textPoint=(34.4356231689453, 10.6086845397949), 
        radius=6.9)

    s2.resetView()
    mdb.models[ModelName].sketches['__edit__'].sketchOptions.setValues(
        sheetSize=1000.0, sheetAuto=OFF)
    s2.ConstructionLine(point1=(0.0, 0.0), point2=(63.0, -109.119201))
    s2.CoincidentConstraint(entity1=v[40], entity2=g[20], addUndoState=False)
    s2.CoincidentConstraint(entity1=v[7], entity2=g[20], addUndoState=False)
    s2.ConstructionLine(point1=(0.0, 0.0), point2=(0.0, -145.492268))
    s2.VerticalConstraint(entity=g[21], addUndoState=False)
    s2.CoincidentConstraint(entity1=v[40], entity2=g[21], addUndoState=False)
    s2.CoincidentConstraint(entity1=v[2], entity2=g[21], addUndoState=False)

    s2.autoTrimCurve(curve1=g[19], point1=(-2.37483406066895, 6.94083786010742))
    s2.autoTrimCurve(curve1=g[18], point1=(-1.96539497375488, 6.12263107299805))
    s2.autoTrimCurve(curve1=g[23], point1=(-4.83146858215332, 5.4407844543457))
    s2.autoTrimCurve(curve1=g[25], point1=(-4.69499397277832, 4.07710647583008))
    s2.autoTrimCurve(curve1=g[24], point1=(-4.55851173400879, -3.42315292358398))

    s2.autoTrimCurve(curve1=g[3], point1=(-6.78574752807617, -33.0287094116211))
    s2.autoTrimCurve(curve1=g[2], point1=(-5.04345321655273, -32.8836326599121))

    s2.autoTrimCurve(curve1=g[6], point1=(-6.52793884277344, -70.0462188720703))
    s2.autoTrimCurve(curve1=g[7], point1=(-6.25726318359375, -67.8826446533203))

    s2.autoTrimCurve(curve1=g[10], point1=(-5.30252456665039, -107.438369750977))
    s2.autoTrimCurve(curve1=g[11], point1=(-6.26545715332031, -104.979553222656))

    s2.autoTrimCurve(curve1=g[17], point1=(-7.31775283813477, -143.601745605469))
    s2.autoTrimCurve(curve1=g[16], point1=(-5.23684692382813, -142.770065307617))

    s2.autoTrimCurve(curve1=g[12], point1=(67.4866180419922, -106.201934814453))
    s2.autoTrimCurve(curve1=g[13], point1=(68.2401809692383, -103.190155029297))

    s2.autoTrimCurve(curve1=g[44], point1=(67.3057403564453, -113.316566467285))
    s2.autoTrimCurve(curve1=g[45], point1=(67.3057403564453, -114.156547546387))

    s2.autoTrimCurve(curve1=g[4], point1=(30.2885398864746, -47.7935371398926))
    s2.autoTrimCurve(curve1=g[5], point1=(32.972282409668, -49.031177520752))
    s2.autoTrimCurve(curve1=g[49], point1=(36.0000915527344, -58.5885047912598))
    s2.autoTrimCurve(curve1=g[48], point1=(36.5506057739258, -59.0698089599609))

    s2.autoTrimCurve(curve1=g[27], point1=(5.28486824035645, -2.66463375091553))
    s2.autoTrimCurve(curve1=g[22], point1=(6.21062850952148, 2.36508846282959))
    s2.autoTrimCurve(curve1=g[26], point1=(5.68988990783691, -4.10995769500732))

    s2.Line(point1=(0.0, -5.9), point2=(0.0, -6.9))
    s2.VerticalConstraint(entity=g[54], addUndoState=False)
    s2.PerpendicularConstraint(entity1=g[52], entity2=g[54], addUndoState=False)
    s2.Line(point1=(2.94999999721112, -5.10954988393835), point2=(3.44999999748932, 
        -5.97557528756217))

    s2.Line(point1=(0.0, -29.473067), point2=(0.0, -30.473067))
    s2.VerticalConstraint(entity=g[56], addUndoState=False)
    s2.PerpendicularConstraint(entity1=g[28], entity2=g[56], addUndoState=False)
    s2.Line(point1=(0.0, -42.273067), point2=(0.0, -43.273067))
    s2.VerticalConstraint(entity=g[57], addUndoState=False)
    s2.PerpendicularConstraint(entity1=g[31], entity2=g[57], addUndoState=False)

    s2.Line(point1=(0.0, -65.846134), point2=(0.0, -66.846134))
    s2.VerticalConstraint(entity=g[58], addUndoState=False)
    s2.PerpendicularConstraint(entity1=g[34], entity2=g[58], addUndoState=False)
    s2.Line(point1=(0.0, -78.646134), point2=(0.0, -79.646134))
    s2.VerticalConstraint(entity=g[59], addUndoState=False)
    s2.PerpendicularConstraint(entity1=g[33], entity2=g[59], addUndoState=False)

    s2.Line(point1=(0.0, -102.219201), point2=(0.0, -103.219201))
    s2.VerticalConstraint(entity=g[60], addUndoState=False)
    s2.PerpendicularConstraint(entity1=g[38], entity2=g[60], addUndoState=False)
    s2.Line(point1=(0.0, -115.019201), point2=(0.0, -116.019201))
    s2.VerticalConstraint(entity=g[61], addUndoState=False)
    s2.PerpendicularConstraint(entity1=g[37], entity2=g[61], addUndoState=False)

    s2.Line(point1=(0.0, -138.592268), point2=(0.0, -139.592268))
    s2.VerticalConstraint(entity=g[62], addUndoState=False)
    s2.PerpendicularConstraint(entity1=g[40], entity2=g[62], addUndoState=False)
    s2.Line(point1=(0.0, -151.392268), point2=(0.0, -152.392268))
    s2.VerticalConstraint(entity=g[63], addUndoState=False)
    s2.PerpendicularConstraint(entity1=g[43], entity2=g[63], addUndoState=False)

    s2.Line(point1=(59.5500000032458, -103.143625712013), point2=(60.0500000028255, 
        -104.009651116041))
    s2.PerpendicularConstraint(entity1=g[47], entity2=g[64], addUndoState=False)
    s2.Line(point1=(65.9499999975719, -114.22875088373), point2=(66.4499999971516, 
        -115.094776287757))
    s2.PerpendicularConstraint(entity1=g[46], entity2=g[65], addUndoState=False)

    s2.Line(point1=(28.0499997863841, -48.5840248372186), point2=(28.5499997858557, 
        -49.4500502413081))
    s2.Line(point1=(34.4499997808183, -59.6691500088728), point2=(34.9499997802899, 
        -60.5351754129623))

    s2.unsetPrimaryObject()
    p = mdb.models[ModelName].parts['Part-2']
    p.features['Shell planar-1'].setValues(sketch=s2)
    del mdb.models[ModelName].sketches['__edit__']

    p = mdb.models[ModelName].parts['Part-2']
    p.regenerate()

    p = mdb.models[ModelName].parts['Part-3']
    s = p.features['Shell planar-1'].sketch
    mdb.models[ModelName].ConstrainedSketch(name='__edit__', 
        objectToCopy=s)
    s1 = mdb.models[ModelName].sketches['__edit__']
    g, v, d, c = s1.geometry, s1.vertices, s1.dimensions, s1.constraints
    s1.setPrimaryObject(option=SUPERIMPOSE)
    p.projectReferencesOntoSketch(sketch=s1, 
        upToFeature=p.features['Shell planar-1'], filter=COPLANAR_EDGES)

    mdb.models[ModelName].sketches['__edit__'].sketchOptions.setValues(
        sheetSize=1000.0, sheetAuto=OFF)
    s1.Spot(point=(0.0, 0.0))

    s1.ConstructionLine(point1=(0.0, 0.0), point2=(52.5, -90.932667))
    s1.CoincidentConstraint(entity1=v[70], entity2=g[32], addUndoState=False)
    s1.CoincidentConstraint(entity1=v[9], entity2=g[32], addUndoState=False)

    s1.autoTrimCurve(curve1=g[13], point1=(12.0939598083496, -12.0526695251465))
    s1.autoTrimCurve(curve1=g[2], point1=(11.8935279846191, -13.1541557312012))
    s1.autoTrimCurve(curve1=g[12], point1=(14.1985092163086, -15.156852722168))

    s1.autoTrimCurve(curve1=g[33], point1=(14.4637823104858, -22.5383834838867))
    s1.autoTrimCurve(curve1=g[34], point1=(13.6905508041382, -22.0748252868652))
    s1.autoTrimCurve(curve1=g[35], point1=(13.5668344497681, -22.0748252868652))

    s1.autoTrimCurve(curve1=g[15], point1=(20.1204204559326, -30.5548667907715))

    s1.autoTrimCurve(curve1=g[3], point1=(24.5441188812256, -33.2044258117676))
    s1.autoTrimCurve(curve1=g[14], point1=(24.6380500793457, -32.9854316711426))
    s1.autoTrimCurve(curve1=g[40], point1=(25.5147399902344, -38.1474342346191))
    s1.autoTrimCurve(curve1=g[41], point1=(25.2016353607178, -39.0234107971191))
    s1.autoTrimCurve(curve1=g[39], point1=(25.3894996643066, -40.2435188293457))

    s1.autoTrimCurve(curve1=g[21], point1=(40.6349449157715, -66.886962890625))
    s1.autoTrimCurve(curve1=g[6], point1=(41.6947937011719, -67.6608352661133))
    s1.autoTrimCurve(curve1=g[20], point1=(41.1241073608398, -67.8237533569336))
    s1.autoTrimCurve(curve1=g[48], point1=(45.3227272033691, -76.2956085205078))
    s1.autoTrimCurve(curve1=g[45], point1=(45.6895980834961, -77.1102066040039))

    s1.autoTrimCurve(curve1=g[8], point1=(51.5962448120117, -86.231330871582))
    s1.autoTrimCurve(curve1=g[24], point1=(51.2485618591309, -86.1541290283203))
    s1.autoTrimCurve(curve1=g[25], point1=(51.1326675415039, -84.9575271606445))
    s1.autoTrimCurve(curve1=g[51], point1=(56.6183624267578, -93.6425628662109))
    s1.autoTrimCurve(curve1=g[52], point1=(56.270679473877, -94.3759613037109))
    s1.autoTrimCurve(curve1=g[53], point1=(56.5410995483398, -95.3023681640625))

    s1.Line(point1=(7.54999981676244, -13.0769832234641), point2=(8.04999981843762, 
        -13.9430086262813))
    s1.Line(point1=(8.09999981897098, -14.0296111663519), point2=(12.9499998345549, 
        -22.4300575740635))

    s1.Line(point1=(12.9499998345549, -22.4300575740635), point2=(13.4499998369286, 
        -23.2960829764775))

    s1.autoTrimCurve(curve1=g[58], point1=(12.937949180603, -22.3988208770752))

    s1.Line(point1=(18.0500000772118, -31.2635170730936), point2=(18.550000078887, 
        -32.1295424759108))

    s1.Line(point1=(18.6000000787218, -32.2161450163846), point2=(23.4000000944709, 
        -40.5299888836225))
    s1.Line(point1=(23.4500000943058, -40.6165914240963), point2=(23.9500000959809, 
        -41.4826168269136))

    s1.Line(point1=(39.050000163675, -67.636584023174), point2=(39.5500001646517, 
        -68.5026094263946))
    s1.Line(point1=(39.600000165185, -68.5892119664651), point2=(44.4000001809341, 
        -76.903055833703))

    s1.Line(point1=(44.4500001814675, -76.9896583737735), point2=(44.9500001824441, 
        -77.855683776994))

    s1.Line(point1=(49.5499999901712, -85.8231171233464), point2=(50.0499999918464, 
        -86.6891425261637))
    s1.PerpendicularConstraint(entity1=g[56], entity2=g[67], addUndoState=False)

    s1.Line(point1=(50.0999999923798, -86.7757450662342), point2=(54.9000000081288, 
        -95.0895889334721))
    s1.PerpendicularConstraint(entity1=g[54], entity2=g[68], addUndoState=False)
    s1.Line(point1=(54.9500000078556, -95.1761914740083), point2=(55.4500000088323, 
        -96.0422168772288))

    s1.unsetPrimaryObject()
    p = mdb.models[ModelName].parts['Part-3']
    p.features['Shell planar-1'].setValues(sketch=s1)
    del mdb.models[ModelName].sketches['__edit__']

    p = mdb.models[ModelName].parts['Part-3']
    p.regenerate()

    try:
        del mdb.models[ModelName].sections['Section-2-SS']
        del mdb.models[ModelName].sections['Section-3-VS']
    except KeyError:
        del mdb.models[ModelName].sections['Section-3-SS']
        del mdb.models[ModelName].sections['Section-2-VS']

    print str(1)   
    del mdb.models[ModelName].parts['PART-1'].sectionAssignments[2]
    print str(1) 
    del mdb.models[ModelName].parts['PART-1'].sectionAssignments[1]


    mdb.models[ModelName].sections['Section-1-_I1'].setValues(material='MATERIAL01', thickness=1500.0, wedgeAngle1=0.0, wedgeAngle2=0.0)
    mdb.models[ModelName].PEGSection(name='Section-SS', material='MATERIAL01', thickness=1500.0, wedgeAngle1=0.0, wedgeAngle2=0.0)
    mdb.models[ModelName].PEGSection(name='Section-VS', material='MATERIAL02', thickness=1500.0, wedgeAngle1=0.0, wedgeAngle2=0.0)
    mdb.models[ModelName].PEGSection(name='Section-UO2', material='MATERIAL-UO2', thickness=1500.0, wedgeAngle1=0.0, wedgeAngle2=0.0)
    p = mdb.models[ModelName].parts['PART-1']
    region = p.sets['SS']
    p = mdb.models[ModelName].parts['PART-1']
    p.SectionAssignment(region=region, sectionName='Section-SS', offset=0.0, 
        offsetType=MIDDLE_SURFACE, offsetField='', 
        thicknessAssignment=FROM_SECTION)
    p = mdb.models[ModelName].parts['PART-1']
    region = p.sets['VS']
    p = mdb.models[ModelName].parts['PART-1']
    p.SectionAssignment(region=region, sectionName='Section-VS', offset=0.0, 
        offsetType=MIDDLE_SURFACE, offsetField='', 
        thicknessAssignment=FROM_SECTION)

    p = mdb.models[ModelName].parts['Part-2']
    f = p.faces
    faces = f.getSequenceFromMask(mask=('[#1ff ]', ), )
    region = regionToolset.Region(faces=faces)
    p = mdb.models[ModelName].parts['Part-2']
    p.SectionAssignment(region=region, sectionName='Section-SS', offset=0.0, 
        offsetType=MIDDLE_SURFACE, offsetField='', 
        thicknessAssignment=FROM_SECTION)
        
    p = mdb.models[ModelName].parts['Part-3']
    f = p.faces
    faces = f.getSequenceFromMask(mask=('[#fe540 ]', ), )
    region = regionToolset.Region(faces=faces)
    p = mdb.models[ModelName].parts['Part-3']
    p.SectionAssignment(region=region, sectionName='Section-SS', offset=0.0, 
        offsetType=MIDDLE_SURFACE, offsetField='', 
        thicknessAssignment=FROM_SECTION)
        
    p = mdb.models[ModelName].parts['Part-3']
    f = p.faces
    faces = f.getSequenceFromMask(mask=('[#1abf ]', ), )
    region = regionToolset.Region(faces=faces)
    p = mdb.models[ModelName].parts['Part-3']
    p.SectionAssignment(region=region, sectionName='Section-UO2', offset=0.0, 
        offsetType=MIDDLE_SURFACE, offsetField='', 
        thicknessAssignment=FROM_SECTION)

     
    a1 = mdb.models[ModelName].rootAssembly
    p = mdb.models[ModelName].parts['Part-2']
    a1.Instance(name='Part-2-1', part=p, dependent=ON)
    p = mdb.models[ModelName].parts['Part-3']
    a1.Instance(name='Part-3-1', part=p, dependent=ON)    

    mdb.models[ModelName].CoupledTempDisplacementStep(name='Step-int', 
        previous='Initial', timePeriod=0.0001, maxNumInc=10000000, 
        initialInc=0.0001, minInc=1e-06, maxInc=0.0001, deltmx=1000.0, cetol=0.36, 
        creepIntegration=IMPLICIT_EXPLICIT)

    mdb.models[ModelName].steps['Step-1'].setValues(nlgeom=OFF)
    mdb.models[ModelName].steps['Step-1'].setValues(response=TRANSIENT, 
        timePeriod=157680000.0, maxNumInc=10000000, 
        timeIncrementationMethod=AUTOMATIC, initialInc=0.01, minInc=1e-05, 
        maxInc=100000000.0, deltmx=1000.0, cetol=0.36, 
        creepIntegration=IMPLICIT_EXPLICIT, amplitude=STEP)
        
    a = mdb.models[ModelName].rootAssembly
    e11 = a.instances['Part-2-1'].edges
    a.ReferencePoint(point=a.instances['Part-2-1'].InterestingPoint(edge=e11[1], 
        rule=CENTER))
    a = mdb.models[ModelName].rootAssembly
    r1 = a.referencePoints
    refPoints1=(r1[65], )
    a.Set(referencePoints=refPoints1, name='RP-0')
    #: The set 'RP-0' has been created (1 reference point).
    a = mdb.models[ModelName].rootAssembly
    e1 = a.instances['Part-3-1'].edges
    a.ReferencePoint(point=a.instances['Part-3-1'].InterestingPoint(edge=e1[5], 
        rule=CENTER))
    a = mdb.models[ModelName].rootAssembly
    r1 = a.referencePoints
    refPoints1=(r1[67], )
    a.Set(referencePoints=refPoints1, name='RP-red-4-out')
    #: The set 'RP-red-4-out' has been created (1 reference point).
    a = mdb.models[ModelName].rootAssembly
    e1 = a.instances['Part-3-1'].edges
    a.ReferencePoint(point=a.instances['Part-3-1'].InterestingPoint(edge=e1[5], 
        rule=CENTER))
    a = mdb.models[ModelName].rootAssembly
    r1 = a.referencePoints
    refPoints1=(r1[69], )    
    a.Set(referencePoints=refPoints1, name='RP-red-4-in')
    #: The set 'RP-red-4-in' has been created (1 reference point).
    a = mdb.models[ModelName].rootAssembly
    e1 = a.instances['Part-3-1'].edges
    a.ReferencePoint(point=a.instances['Part-3-1'].InterestingPoint(edge=e1[5], 
        rule=CENTER))
    r1 = a.referencePoints
    refPoints1=(r1[71], )
    a.Set(referencePoints=refPoints1, name='RP-rod-4-out')
        #: The set 'RP-rod-4-out' has been created (1 reference point).
    a = mdb.models[ModelName].rootAssembly
    e1 = a.instances['Part-3-1'].edges
    a.ReferencePoint(point=a.instances['Part-3-1'].InterestingPoint(edge=e1[5], 
        rule=CENTER))
    r1 = a.referencePoints
    refPoints1=(r1[73], )
    a.Set(referencePoints=refPoints1, name='RP-rod-4-in')
        #: The set 'RP-rod-4-in' has been created (1 reference point).
    a = mdb.models[ModelName].rootAssembly
    e11 = a.instances['Part-3-1'].edges
    a.ReferencePoint(point=a.instances['Part-3-1'].InterestingPoint(edge=e11[4], 
        rule=CENTER))
    a.ReferencePoint(point=a.instances['Part-3-1'].InterestingPoint(edge=e11[4], 
        rule=CENTER))
    a.ReferencePoint(point=a.instances['Part-3-1'].InterestingPoint(edge=e11[4], 
        rule=CENTER))
    a.ReferencePoint(point=a.instances['Part-3-1'].InterestingPoint(edge=e11[4], 
        rule=CENTER))

    r1 = a.referencePoints
    refPoints1=(r1[75], )
    a.Set(referencePoints=refPoints1, name='RP-red-5-out')
    #: The set 'RP-red-5-out' has been created (1 reference point).
    r1 = a.referencePoints
    refPoints1=(r1[76], )
    a.Set(referencePoints=refPoints1, name='RP-red-5-in')
    #: The set 'RP-red-5-in' has been created (1 reference point).
    a = mdb.models[ModelName].rootAssembly
    r1 = a.referencePoints
    refPoints1=(r1[77], )
    a.Set(referencePoints=refPoints1, name='RP-rod-5-out')
    #: The set 'RP-rod-5-out' has been created (1 reference point).
    a = mdb.models[ModelName].rootAssembly
    r1 = a.referencePoints
    refPoints1=(r1[78], )
    a.Set(referencePoints=refPoints1, name='RP-rod-5-in')
    #: The set 'RP-rod-5-in' has been created (1 reference point).
    a = mdb.models[ModelName].rootAssembly
    e1 = a.instances['Part-3-1'].edges
    a.ReferencePoint(point=a.instances['Part-3-1'].InterestingPoint(edge=e1[3], 
        rule=CENTER))
    a.ReferencePoint(point=a.instances['Part-3-1'].InterestingPoint(edge=e1[3], 
        rule=CENTER))
    a.ReferencePoint(point=a.instances['Part-3-1'].InterestingPoint(edge=e1[3], 
        rule=CENTER))
    a.ReferencePoint(point=a.instances['Part-3-1'].InterestingPoint(edge=e1[3], 
        rule=CENTER))
    a = mdb.models[ModelName].rootAssembly
    r1 = a.referencePoints
    refPoints1=(r1[83], )
    a.Set(referencePoints=refPoints1, name='RP-red-6-out')
    #: The set 'RP-red-6-out' has been created (1 reference point).
    r1 = a.referencePoints
    refPoints1=(r1[84], )
    a.Set(referencePoints=refPoints1, name='RP-red-6-in')
    #: The set 'RP-red-6-in' has been created (1 reference point).
    r1 = a.referencePoints
    refPoints1=(r1[85], )
    a.Set(referencePoints=refPoints1, name='RP-rod-6-out')
    #: The set 'RP-rod-6-out' has been created (1 reference point).
    r1 = a.referencePoints
    refPoints1=(r1[86], )
    a.Set(referencePoints=refPoints1, name='RP-rod-6-in')
    #: The set 'RP-rod-6-in' has been created (1 reference point).
    a = mdb.models[ModelName].rootAssembly
    e11 = a.instances['Part-2-1'].edges
    a.ReferencePoint(point=a.instances['Part-2-1'].InterestingPoint(edge=e11[38], 
        rule=CENTER))
    a.ReferencePoint(point=a.instances['Part-2-1'].InterestingPoint(edge=e11[38], 
        rule=CENTER))
    a.ReferencePoint(point=a.instances['Part-2-1'].InterestingPoint(edge=e11[38], 
        rule=CENTER))
    a.ReferencePoint(point=a.instances['Part-2-1'].InterestingPoint(edge=e11[38], 
        rule=CENTER))
    a = mdb.models[ModelName].rootAssembly
    r1 = a.referencePoints
    refPoints1=(r1[91], )
    a.Set(referencePoints=refPoints1, name='RP-rod-6-out-1')
    #: The set 'RP-rod-6-out-1' has been created (1 reference point).

    r1 = a.referencePoints
    refPoints1=(r1[92], )
    a.Set(referencePoints=refPoints1, name='RP-rod-6-in-1')
    #: The set 'RP-rod-6-in-1' has been created (1 reference point).

    r1 = a.referencePoints
    refPoints1=(r1[93], )
    a.Set(referencePoints=refPoints1, name='RP-rod-6-outo-1')
    #: The set 'RP-rod-6-outo-1' has been created (1 reference point).
    a = mdb.models[ModelName].rootAssembly
    e1 = a.instances['Part-3-1'].edges
    a.ReferencePoint(point=a.instances['Part-3-1'].InterestingPoint(edge=e1[2], 
        rule=CENTER))
    a.ReferencePoint(point=a.instances['Part-3-1'].InterestingPoint(edge=e1[2], 
        rule=CENTER))
    a.ReferencePoint(point=a.instances['Part-3-1'].InterestingPoint(edge=e1[2], 
        rule=CENTER))
    a.ReferencePoint(point=a.instances['Part-3-1'].InterestingPoint(edge=e1[2], 
        rule=CENTER))
    a = mdb.models[ModelName].rootAssembly
    r1 = a.referencePoints
    refPoints1=(r1[98], )
    a.Set(referencePoints=refPoints1, name='RP-rod-7-out')
    #: The set 'RP-rod-7-out' has been created (1 reference point).
    refPoints1=(r1[99], )
    a.Set(referencePoints=refPoints1, name='RP-rod-7-in')
    #: The set 'RP-rod-7-in' has been created (1 reference point).
    refPoints1=(r1[100], )
    a.Set(referencePoints=refPoints1, name='RP-red-7-out')
    #: The set 'RP-red-7-out' has been created (1 reference point).
    refPoints1=(r1[101], )
    a.Set(referencePoints=refPoints1, name='RP-red-7-in')
    #: The set 'RP-red-7-in' has been created (1 reference point).
    a = mdb.models[ModelName].rootAssembly
    e11 = a.instances['Part-3-1'].edges
    a.ReferencePoint(point=a.instances['Part-3-1'].InterestingPoint(edge=e11[1], 
        rule=CENTER))
    a.ReferencePoint(point=a.instances['Part-3-1'].InterestingPoint(edge=e11[1], 
        rule=CENTER))
    a.ReferencePoint(point=a.instances['Part-3-1'].InterestingPoint(edge=e11[1], 
        rule=CENTER))
    a.ReferencePoint(point=a.instances['Part-3-1'].InterestingPoint(edge=e11[1], 
        rule=CENTER))
    a = mdb.models[ModelName].rootAssembly
    r1 = a.referencePoints
    refPoints1=(r1[106], )
    a.Set(referencePoints=refPoints1, name='RP-rod-7-out-1')
    #: The set 'RP-rod-7-out-1' has been created (1 reference point).
    refPoints1=(r1[107], )
    a.Set(referencePoints=refPoints1, name='RP-red-7-out-1')
    #: The set 'RP-red-7-out-1' has been created (1 reference point).
    refPoints1=(r1[108], )
    a.Set(referencePoints=refPoints1, name='RP-rod-7-in-1')
    #: The set 'RP-rod-7-in-1' has been created (1 reference point).
    refPoints1=(r1[109], )
    a.Set(referencePoints=refPoints1, name='RP-red-7-in-1')
    #: The set 'RP-rod-7-in-1' has been edited (1 reference point).

    a = mdb.models[ModelName].rootAssembly
    e1 = a.instances['Part-3-1'].edges
    a.ReferencePoint(point=a.instances['Part-3-1'].InterestingPoint(edge=e1[0], 
        rule=CENTER))
    a.ReferencePoint(point=a.instances['Part-3-1'].InterestingPoint(edge=e1[0], 
        rule=CENTER))
    a.ReferencePoint(point=a.instances['Part-3-1'].InterestingPoint(edge=e1[0], 
        rule=CENTER))
    a.ReferencePoint(point=a.instances['Part-3-1'].InterestingPoint(edge=e1[0], 
        rule=CENTER))
    a = mdb.models[ModelName].rootAssembly
    r1 = a.referencePoints
    refPoints1=(r1[117], )
    a.Set(referencePoints=refPoints1, name='RP-rod-8-out')
    #: The set 'RP-rod-8-out' has been created (1 reference point).
    refPoints1=(r1[116], )
    a.Set(referencePoints=refPoints1, name='RP-rod-8-in')
    #: The set 'RP-rod-8-in' has been created (1 reference point).
    refPoints1=(r1[115], )
    a.Set(referencePoints=refPoints1, name='RP-red-8-out')
    #: The set 'RP-red-8-out' has been created (1 reference point).
    refPoints1=(r1[114], )
    a.Set(referencePoints=refPoints1, name='RP-red-8-in')
    #: The set 'RP-red-8-in' has been created (1 reference point).
    a = mdb.models[ModelName].rootAssembly
    e11 = a.instances['Part-2-1'].edges
    a.ReferencePoint(point=a.instances['Part-2-1'].InterestingPoint(edge=e11[36], 
        rule=CENTER))
    a.ReferencePoint(point=a.instances['Part-2-1'].InterestingPoint(edge=e11[36], 
        rule=CENTER))
    a.ReferencePoint(point=a.instances['Part-2-1'].InterestingPoint(edge=e11[36], 
        rule=CENTER))
    a = mdb.models[ModelName].rootAssembly
    r1 = a.referencePoints
    refPoints1=(r1[124], )
    a.Set(referencePoints=refPoints1, name='RP-rod-8-out-1')
    #: The set 'RP-rod-8-out-1' has been created (1 reference point).
    refPoints1=(r1[123], )
    a.Set(referencePoints=refPoints1, name='RP-rod-8-in-1')
    #: The set 'RP-rod-8-in-1' has been created (1 reference point).
    refPoints1=(r1[122], )
    a.Set(referencePoints=refPoints1, name='RP-red-8-out-1')
    #: The set 'RP-red-8-out-1' has been created (1 reference point).


    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#20 ]', ), )
    a.Surface(side1Edges=side1Edges1, name='Surf-red-4-in')
    #: The surface 'Surf-red-4-in' has been created (1 edge).
    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#0 #200 ]', ), )
    a.Surface(side1Edges=side1Edges1, name='Surf-red-4-out')
    #: The surface 'Surf-red-4-out' has been created (1 edge).
    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#0 #400 ]', ), )
    a.Surface(side1Edges=side1Edges1, name='Surf-rod-4-in')
    #: The surface 'Surf-rod-4-in' has been created (1 edge).

    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=(
        '[#0:2 #f0000000 #17ef3c #0:42 #fffffffc #ffffffff #3fffffff ]', ), )
    a.Set(nodes=nodes1, name='Surf-rod-4-out')
    #: The set 'Surf-rod-4-out' has been created (107 nodes).


    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=(
        '[#0:8 #ff800000 #3ff #0:92 #f0000000 #ffffffff:2 #ffffff ]', ), )
    a.Set(nodes=nodes1, name='Surf-rod-5-out')
    #: The set 'Surf-rod-5-out' has been created (111 nodes).

    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=(
        '[#0:3 #79c00000 #7dbd #0:47 #fffffe00 #ffffffff:2 #ff ]', ), )
    a.Set(nodes=nodes1, name='Surf-rod-6-out')
    #: The set 'Surf-rod-6-out' has been created (108 nodes).

    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=(
        '[#0:5 #8e64 #0:59 #ffff8000 #ffffffff:3 #3 ]', ), )
    a.Set(nodes=nodes1, name='Surf-rod-6-out-2')
    #: The set 'Surf-rod-6-out-2' has been created (122 nodes).

    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=(
        '[#0:8 #7ffff0 #0:91 #fffffff8 #ffffffff #fffffff ]', ), )
    a.Set(nodes=nodes1, name='Surf-rod-7-out')
    #: The set 'Surf-rod-7-out' has been created (108 nodes).

    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=(
        '[#40000000 #fb7ae #0:18 #fffffe00 #ffffffff:2 #7ff ]', ), )
    a.Set(nodes=nodes1, name='Surf-rod-7-out-2')
    #: The set 'Surf-rod-7-out-2' has been created (114 nodes).

    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=(
        '[#0:5 #b8fe0000 #fd #0:68 #c0000000 #ffffffff:2 #7ffffff ]', ), )
    a.Set(nodes=nodes1, name='Surf-rod-8-out')
    #: The set 'Surf-rod-8-out' has been created (111 nodes).

    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=(
        '[#0:4 #48000000 #3 #0:53 #fffffff0 #ffffffff:2 #1ffffff ]', ), )
    a.Set(nodes=nodes1, name='Surf-rod-8-out-2')
    #: The set 'Surf-rod-8-out-2' has been created (121 nodes).

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#0 #100 ]', ), )
    a.Surface(side1Edges=side1Edges1, name='Surf-rod-5-in')
    #: The surface 'Surf-rod-5-in' has been created (1 edge).

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#10 ]', ), )
    a.Surface(side1Edges=side1Edges1, name='Surf-red-5-in')
    #: The surface 'Surf-red-5-in' has been created (1 edge).
    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#0 #80 ]', ), )
    a.Surface(side1Edges=side1Edges1, name='Surf-red-5-out')
    #: The surface 'Surf-red-5-out' has been created (1 edge).

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#0 #40 ]', ), )
    a.Surface(side1Edges=side1Edges1, name='Surf-rod-6-in')
    #: The surface 'Surf-rod-6-in' has been created (1 edge).
    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#0 #20 ]', ), )
    a.Surface(side1Edges=side1Edges1, name='Surf-red-6-out')
    #: The surface 'Surf-red-6-out' has been created (1 edge).
    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#8 ]', ), )
    a.Surface(side1Edges=side1Edges1, name='Surf-red-6-in')
    #: The surface 'Surf-red-6-in' has been created (1 edge).

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-2-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#0 #80 ]', ), )
    a.Surface(side1Edges=side1Edges1, name='Surf-rod-6-out-1')
    #: The surface 'Surf-rod-6-out-1' has been created (1 edge).
    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-2-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#0 #40 ]', ), )
    a.Surface(side1Edges=side1Edges1, name='Surf-rod-6-in-1')
    #: The surface 'Surf-rod-6-in-1' has been created (1 edge).

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#0 #10 ]', ), )
    a.Surface(side1Edges=side1Edges1, name='Surf-rod-7-in')
    #: The surface 'Surf-rod-7-in' has been created (1 edge).
    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#0 #8 ]', ), )
    a.Surface(side1Edges=side1Edges1, name='Surf-red-7-out')
    #: The surface 'Surf-red-7-out' has been created (1 edge).

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#4 ]', ), )
    a.Surface(side1Edges=side1Edges1, name='Surf-red-7-in')
    #: The surface 'Surf-red-7-in' has been created (1 edge).

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#0 #4 ]', ), )
    a.Surface(side1Edges=side1Edges1, name='Surf-rod-7-in-2')
    #: The surface 'Surf-rod-7-in-2' has been created (1 edge).

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#2 ]', ), )
    a.Surface(side1Edges=side1Edges1, name='Surf-red-7-in-2')
    #: The surface 'Surf-red-7-in-2' has been created (1 edge).

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#0 #2 ]', ), )
    a.Surface(side1Edges=side1Edges1, name='Surf-red-7-out-2')
    #: The surface 'Surf-red-7-out-2' has been created (1 edge).

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#0 #1 ]', ), )
    a.Surface(side1Edges=side1Edges1, name='Surf-rod-8-in')
    #: The surface 'Surf-rod-8-in' has been created (1 edge).

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#1 ]', ), )
    a.Surface(side1Edges=side1Edges1, name='Surf-red-8-in')
    #: The surface 'Surf-red-8-in' has been created (1 edge).
    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#80000000 ]', ), )
    a.Surface(side1Edges=side1Edges1, name='Surf-red-8-out')
    #: The surface 'Surf-red-8-out' has been created (1 edge).

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-2-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#0 #20 ]', ), )
    a.Surface(side1Edges=side1Edges1, name='Surf-rod-8-out-2')
    #: The surface 'Surf-rod-8-out-2' has been created (1 edge).
    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-2-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#0 #10 ]', ), )
    a.Surface(side1Edges=side1Edges1, name='Surf-red-8-out-2')
    #: The surface 'Surf-red-8-out-2' has been created (1 edge).

    a = mdb.models[ModelName].rootAssembly
    region1=a.sets['RP-red-4-in']
    a = mdb.models[ModelName].rootAssembly
    region2=a.surfaces['Surf-red-4-in']
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].Coupling(name='Constraint-1', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=DISTRIBUTING, weightingMethod=UNIFORM, localCsys=datum, u1=ON, 
        u2=ON, ur3=ON)
    a = mdb.models[ModelName].rootAssembly
    region1=a.sets['RP-red-4-out']
    a = mdb.models[ModelName].rootAssembly
    region2=a.surfaces['Surf-red-4-out']
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].Coupling(name='Constraint-2', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=DISTRIBUTING, weightingMethod=UNIFORM, localCsys=datum, u1=ON, 
        u2=ON, ur3=ON)
    a = mdb.models[ModelName].rootAssembly
    region1=a.sets['RP-rod-4-in']
    a = mdb.models[ModelName].rootAssembly
    region2=a.surfaces['Surf-rod-4-in']
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].Coupling(name='Constraint-3', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=DISTRIBUTING, weightingMethod=UNIFORM, localCsys=datum, u1=ON, 
        u2=ON, ur3=ON)
    a = mdb.models[ModelName].rootAssembly
    region1=a.sets['RP-rod-4-out']
    a = mdb.models[ModelName].rootAssembly
    region2=a.sets['Surf-rod-4-out']
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].Coupling(name='Constraint-4', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=DISTRIBUTING, weightingMethod=UNIFORM, localCsys=datum, u1=ON, 
        u2=ON, ur3=ON)

    a = mdb.models[ModelName].rootAssembly
    region1=a.sets['RP-red-5-in']
    a = mdb.models[ModelName].rootAssembly
    region2=a.surfaces['Surf-red-5-in']
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].Coupling(name='Constraint-5', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=DISTRIBUTING, weightingMethod=UNIFORM, localCsys=datum, u1=ON, 
        u2=ON, ur3=ON)
    a = mdb.models[ModelName].rootAssembly
    region1=a.sets['RP-red-5-out']
    a = mdb.models[ModelName].rootAssembly
    region2=a.surfaces['Surf-red-5-out']
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].Coupling(name='Constraint-6', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=DISTRIBUTING, weightingMethod=UNIFORM, localCsys=datum, u1=ON, 
        u2=ON, ur3=ON)
    a = mdb.models[ModelName].rootAssembly
    region1=a.sets['RP-rod-5-in']
    a = mdb.models[ModelName].rootAssembly
    region2=a.surfaces['Surf-rod-5-in']
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].Coupling(name='Constraint-7', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=DISTRIBUTING, weightingMethod=UNIFORM, localCsys=datum, u1=ON, 
        u2=ON, ur3=ON)
    a = mdb.models[ModelName].rootAssembly
    region1=a.sets['RP-rod-5-out']
    a = mdb.models[ModelName].rootAssembly
    region2=a.sets['Surf-rod-5-out']
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].Coupling(name='Constraint-8', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=DISTRIBUTING, weightingMethod=UNIFORM, localCsys=datum, u1=ON, 
        u2=ON, ur3=ON)
    a = mdb.models[ModelName].rootAssembly
    region1=a.sets['RP-red-6-in']
    a = mdb.models[ModelName].rootAssembly
    region2=a.surfaces['Surf-red-6-in']
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].Coupling(name='Constraint-9', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=DISTRIBUTING, weightingMethod=UNIFORM, localCsys=datum, u1=ON, 
        u2=ON, ur3=ON)
    a = mdb.models[ModelName].rootAssembly
    region1=a.sets['RP-red-6-out']
    a = mdb.models[ModelName].rootAssembly
    region2=a.surfaces['Surf-red-6-out']
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].Coupling(name='Constraint-10', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=DISTRIBUTING, weightingMethod=UNIFORM, localCsys=datum, u1=ON, 
        u2=ON, ur3=ON)
        
    a = mdb.models[ModelName].rootAssembly
    region1=a.sets['RP-rod-6-in']
    a = mdb.models[ModelName].rootAssembly
    region2=a.surfaces['Surf-rod-6-in']
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].Coupling(name='Constraint-10-1', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=DISTRIBUTING, weightingMethod=UNIFORM, localCsys=datum, u1=ON, 
        u2=ON, ur3=ON)    
        
        
    a = mdb.models[ModelName].rootAssembly
    region1=a.sets['RP-rod-6-in']
    a = mdb.models[ModelName].rootAssembly
    region2=a.sets['Surf-rod-6-out']
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].Coupling(name='Constraint-11', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=DISTRIBUTING, weightingMethod=UNIFORM, localCsys=datum, u1=ON, 
        u2=ON, ur3=ON)
    a = mdb.models[ModelName].rootAssembly
    region1=a.sets['RP-rod-6-outo-1']
    a = mdb.models[ModelName].rootAssembly
    region2=a.surfaces['Surf-rod-6-in-1']
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].Coupling(name='Constraint-12', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=DISTRIBUTING, weightingMethod=UNIFORM, localCsys=datum, u1=ON, 
        u2=ON, ur3=ON)
    a = mdb.models[ModelName].rootAssembly
    region1=a.sets['RP-rod-6-out-1']
    a = mdb.models[ModelName].rootAssembly
    region2=a.surfaces['Surf-rod-6-out-1']
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].Coupling(name='Constraint-13', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=DISTRIBUTING, weightingMethod=UNIFORM, localCsys=datum, u1=ON, 
        u2=ON, ur3=ON)
    a = mdb.models[ModelName].rootAssembly
    region1=a.sets['RP-rod-6-outo-1']
    a = mdb.models[ModelName].rootAssembly
    region2=a.sets['Surf-rod-6-out-2']
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].Coupling(name='Constraint-14', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=DISTRIBUTING, weightingMethod=UNIFORM, localCsys=datum, u1=ON, 
        u2=ON, ur3=ON)
    a = mdb.models[ModelName].rootAssembly
    region1=a.sets['RP-rod-7-in']
    a = mdb.models[ModelName].rootAssembly
    region2=a.surfaces['Surf-red-7-in']
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].Coupling(name='Constraint-15', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=DISTRIBUTING, weightingMethod=UNIFORM, localCsys=datum, u1=ON, 
        u2=ON, ur3=ON)
        
    a = mdb.models[ModelName].rootAssembly
    region1=a.sets['RP-red-7-out']
    a = mdb.models[ModelName].rootAssembly
    region2=a.surfaces['Surf-red-7-out']
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].Coupling(name='Constraint-15-1', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=DISTRIBUTING, weightingMethod=UNIFORM, localCsys=datum, u1=ON, 
        u2=ON, ur3=ON)

    a = mdb.models[ModelName].rootAssembly
    region1=a.sets['RP-rod-7-in']
    a = mdb.models[ModelName].rootAssembly
    region2=a.surfaces['Surf-rod-7-in']
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].Coupling(name='Constraint-16', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=DISTRIBUTING, weightingMethod=UNIFORM, localCsys=datum, u1=ON, 
        u2=ON, ur3=ON)
    a = mdb.models[ModelName].rootAssembly
    region1=a.sets['RP-rod-7-out']
    a = mdb.models[ModelName].rootAssembly
    region2=a.sets['Surf-rod-7-out']
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].Coupling(name='Constraint-17', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=DISTRIBUTING, weightingMethod=UNIFORM, localCsys=datum, u1=ON, 
        u2=ON, ur3=ON)

    a = mdb.models[ModelName].rootAssembly
    region1=a.sets['RP-red-7-out-1']
    a = mdb.models[ModelName].rootAssembly
    region2=a.surfaces['Surf-red-7-in-2']
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].Coupling(name='Constraint-18', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=DISTRIBUTING, weightingMethod=UNIFORM, localCsys=datum, u1=ON, 
        u2=ON, ur3=ON)

    a = mdb.models[ModelName].rootAssembly
    e1 = a.instances['Part-3-1'].edges
    a.ReferencePoint(point=a.instances['Part-3-1'].InterestingPoint(edge=e1[1], 
        rule=CENTER))


    a = mdb.models[ModelName].rootAssembly
    region1=a.sets['RP-red-7-in-1']
    mdb.models[ModelName].constraints['Constraint-18'].setValues(
        controlPoint=region1)
    a = mdb.models[ModelName].rootAssembly
    region1=a.sets['RP-red-7-out-1']
    a = mdb.models[ModelName].rootAssembly
    region2=a.surfaces['Surf-red-7-out-2']
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].Coupling(name='Constraint-19', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=DISTRIBUTING, weightingMethod=UNIFORM, localCsys=datum, u1=ON, 
        u2=ON, ur3=ON)
    a = mdb.models[ModelName].rootAssembly
    region1=a.sets['RP-rod-7-in-1']
    a = mdb.models[ModelName].rootAssembly
    region2=a.surfaces['Surf-rod-7-in-2']
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].Coupling(name='Constraint-20', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=DISTRIBUTING, weightingMethod=UNIFORM, localCsys=datum, u1=ON, 
        u2=ON, ur3=ON)
    a = mdb.models[ModelName].rootAssembly
    region1=a.sets['RP-rod-7-out-1']
    a = mdb.models[ModelName].rootAssembly
    region2=a.sets['Surf-rod-7-out-2']
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].Coupling(name='Constraint-21', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=DISTRIBUTING, weightingMethod=UNIFORM, localCsys=datum, u1=ON, 
        u2=ON, ur3=ON)

    a = mdb.models[ModelName].rootAssembly
    region1=a.sets['RP-red-8-in']
    a = mdb.models[ModelName].rootAssembly
    region2=a.surfaces['Surf-red-8-in']
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].Coupling(name='Constraint-22', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=DISTRIBUTING, weightingMethod=UNIFORM, localCsys=datum, u1=ON, 
        u2=ON, ur3=ON)

    a = mdb.models[ModelName].rootAssembly
    region1=a.sets['RP-red-8-out']
    a = mdb.models[ModelName].rootAssembly
    region2=a.surfaces['Surf-red-8-out']
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].Coupling(name='Constraint-23', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=DISTRIBUTING, weightingMethod=UNIFORM, localCsys=datum, u1=ON, 
        u2=ON, ur3=ON)
    a = mdb.models[ModelName].rootAssembly
    region1=a.sets['RP-rod-8-in']
    a = mdb.models[ModelName].rootAssembly
    region2=a.surfaces['Surf-rod-8-in']
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].Coupling(name='Constraint-24', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=DISTRIBUTING, weightingMethod=UNIFORM, localCsys=datum, u1=ON, 
        u2=ON, ur3=ON)

    a = mdb.models[ModelName].rootAssembly
    region1=a.sets['RP-rod-8-out']
    a = mdb.models[ModelName].rootAssembly
    region2=a.sets['Surf-rod-8-out']
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].Coupling(name='Constraint-25', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=DISTRIBUTING, weightingMethod=UNIFORM, localCsys=datum, u1=ON, 
        u2=ON, ur3=ON)

    a = mdb.models[ModelName].rootAssembly
    region1=a.sets['RP-red-8-out-1']
    a = mdb.models[ModelName].rootAssembly
    region2=a.surfaces['Surf-red-8-out-2']
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].Coupling(name='Constraint-26', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=DISTRIBUTING, weightingMethod=UNIFORM, localCsys=datum, u1=ON, 
        u2=ON, ur3=ON)
    a = mdb.models[ModelName].rootAssembly
    region1=a.sets['RP-rod-8-in-1']
    a = mdb.models[ModelName].rootAssembly
    region2=a.surfaces['Surf-rod-8-out-2']
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].Coupling(name='Constraint-27', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=DISTRIBUTING, weightingMethod=UNIFORM, localCsys=datum, u1=ON, 
        u2=ON, ur3=ON)
    a = mdb.models[ModelName].rootAssembly
    region1=a.sets['RP-rod-8-out-1']
    a = mdb.models[ModelName].rootAssembly
    region2=a.sets['Surf-rod-8-out-2']
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].Coupling(name='Constraint-28', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=DISTRIBUTING, weightingMethod=UNIFORM, localCsys=datum, u1=ON, 
        u2=ON, ur3=ON)
            
    mdb.models[ModelName].Equation(name='Constraint-29', terms=((1.0, 
        'RP-red-4-in', 1, 59), (-1.0, 'RP-red-4-out', 1, 59), (-1.0, 'RP-0', 1, 
        59)))
    mdb.models[ModelName].Equation(name='Constraint-30', terms=((1.0, 
        'RP-rod-4-in', 1, 59), (-1.0, 'RP-rod-4-out', 1, 59), (-1.0, 'RP-0', 1, 
        59)))
    mdb.models[ModelName].Constraint(name='Constraint-29-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-29'])
    mdb.models[ModelName].constraints['Constraint-29-Copy'].setValues(
        terms=((1.0, 'RP-red-4-in', 2, 59), (-1.0, 'RP-red-4-out', 2, 59), (-1.0, 
        'RP-0', 2, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-29-Copy-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-29-Copy'])
    mdb.models[ModelName].constraints['Constraint-29-Copy-Copy'].setValues(
        terms=((1.0, 'RP-red-4-in', 6, 59), (-1.0, 'RP-red-4-out', 6, 59), (-1.0, 
        'RP-0', 6, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-30-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-30'])
    mdb.models[ModelName].constraints['Constraint-30-Copy'].setValues(
        terms=((1.0, 'RP-rod-4-in', 2, 59), (-1.0, 'RP-rod-4-out', 2, 59), (-1.0, 
        'RP-0', 2, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-30-Copy-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-30-Copy'])
    mdb.models[ModelName].constraints['Constraint-30-Copy-Copy'].setValues(
        terms=((1.0, 'RP-rod-4-in', 6, 59), (-1.0, 'RP-rod-4-out', 6, 59), (-1.0, 
        'RP-0', 6, 59)))
    mdb.models[ModelName].Equation(name='Constraint-35', terms=((1.0, 
        'RP-red-5-in', 1, 59), (-1.0, 'RP-red-5-out', 1, 59), (-1.0, 'RP-0', 1, 
        59)))
    mdb.models[ModelName].Constraint(name='Constraint-35-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-35'])
    mdb.models[ModelName].constraints['Constraint-35-Copy'].setValues(
        terms=((1.0, 'RP-red-5-in', 2, 59), (-1.0, 'RP-red-5-out', 2, 59), (-1.0, 
        'RP-0', 2, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-35-Copy-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-35-Copy'])
    mdb.models[ModelName].constraints['Constraint-35-Copy-Copy'].setValues(
        terms=((1.0, 'RP-red-5-in', 6, 59), (-1.0, 'RP-red-5-out', 6, 59), (-1.0, 
        'RP-0', 6, 59)))

    mdb.models[ModelName].Equation(name='Constraint-38', terms=((1.0, 
        'RP-red-6-in', 1, 59), (-1.0, 'RP-red-6-out', 1, 59), (-1.0, 'RP-0', 1, 
        59)))
    mdb.models[ModelName].Constraint(name='Constraint-38-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-38'])
    mdb.models[ModelName].constraints['Constraint-38-Copy'].setValues(
        terms=((1.0, 'RP-red-6-in', 2, 59), (-1.0, 'RP-red-6-out', 2, 59), (-1.0, 
        'RP-0', 2, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-38-Copy-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-38-Copy'])
    mdb.models[ModelName].constraints['Constraint-38-Copy-Copy'].setValues(
        terms=((1.0, 'RP-red-6-in', 6, 59), (-1.0, 'RP-red-6-out', 6, 59), (-1.0, 
        'RP-0', 6, 59)))
    mdb.models[ModelName].Equation(name='Constraint-41', terms=((1.0, 
        'RP-rod-6-in', 1, 59), (-1.0, 'RP-rod-6-out', 1, 59), (-1.0, 'RP-0', 1, 
        59)))
    mdb.models[ModelName].Constraint(name='Constraint-41-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-41'])
    mdb.models[ModelName].constraints['Constraint-41-Copy'].setValues(
        terms=((1.0, 'RP-rod-6-in', 2, 59), (-1.0, 'RP-rod-6-out', 2, 59), (-1.0, 
        'RP-0', 2, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-41-Copy-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-41-Copy'])
    mdb.models[ModelName].constraints['Constraint-41-Copy-Copy'].setValues(
        terms=((1.0, 'RP-rod-6-in', 6, 59), (-1.0, 'RP-rod-6-out', 6, 59), (-1.0, 
        'RP-0', 6, 59)))
    mdb.models[ModelName].Equation(name='Constraint-44', terms=((1.0, 
        'RP-rod-6-in-1', 1, 59), (-1.0, 'RP-rod-6-out-1', 1, 59), (-1.0, 'RP-0', 1, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-44-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-44'])
    mdb.models[ModelName].constraints['Constraint-44-Copy'].setValues(
        terms=((1.0, 'RP-rod-6-in-1', 2, 59), (-1.0, 'RP-rod-6-out-1', 2, 59), (
        -1.0, 'RP-0', 2, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-44-Copy-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-44-Copy'])
    mdb.models[ModelName].constraints['Constraint-44-Copy-Copy'].setValues(
        terms=((1.0, 'RP-rod-6-in-1', 6, 59), (-1.0, 'RP-rod-6-out-1', 6, 59), (
        -1.0, 'RP-0', 6, 59)))
    mdb.models[ModelName].Equation(name='Constraint-47', terms=((1.0, 
        'RP-rod-6-out-1', 1, 59), (-1.0, 'RP-rod-6-outo-1', 1, 59), (-1.0, 'RP-0', 
        1, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-47-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-47'])
    mdb.models[ModelName].constraints['Constraint-47-Copy'].setValues(
        terms=((1.0, 'RP-rod-6-out-1', 2, 59), (-1.0, 'RP-rod-6-outo-1', 2, 59), (
        -1.0, 'RP-0', 2, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-47-Copy-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-47-Copy'])
    mdb.models[ModelName].constraints['Constraint-47-Copy-Copy'].setValues(
        terms=((1.0, 'RP-rod-6-out-1', 6, 59), (-1.0, 'RP-rod-6-outo-1', 6, 59), (
        -1.0, 'RP-0', 6, 59)))

    mdb.models[ModelName].Equation(name='Constraint-50', terms=((1.0, 
        'RP-red-7-in', 1, 59), (-1.0, 'RP-red-7-out', 1, 59), (-1.0, 'RP-0', 1, 
        59)))
    mdb.models[ModelName].Constraint(name='Constraint-50-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-50'])
    mdb.models[ModelName].constraints['Constraint-50-Copy'].setValues(
        terms=((1.0, 'RP-red-7-in', 2, 59), (-1.0, 'RP-red-7-out', 2, 59), (-1.0, 
        'RP-0', 2, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-50-Copy-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-50-Copy'])
    mdb.models[ModelName].constraints['Constraint-50-Copy-Copy'].setValues(
        terms=((1.0, 'RP-red-7-in', 6, 59), (-1.0, 'RP-red-7-out', 6, 59), (-1.0, 
        'RP-0', 6, 59)))
    mdb.models[ModelName].Equation(name='Constraint-53', terms=((1.0, 
        'RP-rod-7-in-1', 1, 59), (-1.0, 'RP-rod-7-out-1', 1, 59), (-1.0, 'RP-0', 1, 
        59)))
    mdb.models[ModelName].Constraint(name='Constraint-53-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-53'])
    mdb.models[ModelName].constraints['Constraint-53-Copy'].setValues(
        terms=((1.0, 'RP-rod-7-in-1', 2, 59), (-1.0, 'RP-rod-7-out-1', 2, 59), (
        -1.0, 'RP-0', 2, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-53-Copy-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-53-Copy'])
    mdb.models[ModelName].constraints['Constraint-53-Copy-Copy'].setValues(
        terms=((1.0, 'RP-rod-7-in-1', 6, 59), (-1.0, 'RP-rod-7-out-1', 6, 59), (
        -1.0, 'RP-0', 6, 59)))
    mdb.models[ModelName].Equation(name='Constraint-56', terms=((1.0, 
        'RP-rod-7-in', 1, 59), (-1.0, 'RP-rod-7-out', 1, 59), (-1.0, 'RP-0', 1, 
        59)))
    mdb.models[ModelName].Constraint(name='Constraint-56-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-56'])
    mdb.models[ModelName].constraints['Constraint-56-Copy'].setValues(
        terms=((1.0, 'RP-rod-7-in', 2, 59), (-1.0, 'RP-rod-7-out', 2, 59), (-1.0, 
        'RP-0', 2, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-56-Copy-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-56-Copy'])
    mdb.models[ModelName].constraints['Constraint-56-Copy-Copy'].setValues(
        terms=((1.0, 'RP-rod-7-in', 6, 59), (-1.0, 'RP-rod-7-out', 6, 59), (-1.0, 
        'RP-0', 6, 59)))
    mdb.models[ModelName].Equation(name='Constraint-59', terms=((1.0, 
        'RP-red-7-in-1', 1, 59), (-1.0, 'RP-red-7-out-1', 1, 59), (-1.0, 'RP-0', 1, 
        59)))
    mdb.models[ModelName].Constraint(name='Constraint-59-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-59'])
    mdb.models[ModelName].constraints['Constraint-59-Copy'].setValues(
        terms=((1.0, 'RP-red-7-in-1', 2, 59), (-1.0, 'RP-red-7-out-1', 2, 59), (
        -1.0, 'RP-0', 2, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-59-Copy-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-59-Copy'])
    mdb.models[ModelName].constraints['Constraint-59-Copy-Copy'].setValues(
        terms=((1.0, 'RP-red-7-in-1', 6, 59), (-1.0, 'RP-red-7-out-1', 6, 59), (
        -1.0, 'RP-0', 6, 59)))

    mdb.models[ModelName].Equation(name='Constraint-62', terms=((1.0, 
        'RP-red-8-in', 1, 59), (-1.0, 'RP-red-8-out', 1, 59), (-1.0, 'RP-0', 1, 
        59)))
    mdb.models[ModelName].Constraint(name='Constraint-62-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-62'])
    mdb.models[ModelName].constraints['Constraint-62-Copy'].setValues(
        terms=((1.0, 'RP-red-8-in', 2, 59), (-1.0, 'RP-red-8-out', 2, 59), (-1.0, 
        'RP-0', 2, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-62-Copy-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-62-Copy'])
    mdb.models[ModelName].constraints['Constraint-62-Copy-Copy'].setValues(
        terms=((1.0, 'RP-red-8-in', 6, 59), (-1.0, 'RP-red-8-out', 6, 59), (-1.0, 
        'RP-0', 6, 59)))
    mdb.models[ModelName].Equation(name='Constraint-65', terms=((1.0, 
        'RP-rod-8-in', 1, 59), (-1.0, 'RP-rod-8-out', 1, 59), (-1.0, 'RP-0', 1, 
        59)))
    mdb.models[ModelName].Constraint(name='Constraint-65-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-65'])
    mdb.models[ModelName].constraints['Constraint-65-Copy'].setValues(
        terms=((1.0, 'RP-rod-8-in', 2, 59), (-1.0, 'RP-rod-8-out', 2, 59), (-1.0, 
        'RP-0', 2, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-65-Copy-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-65-Copy'])
    mdb.models[ModelName].constraints['Constraint-65-Copy-Copy'].setValues(
        terms=((1.0, 'RP-rod-8-in', 6, 59), (-1.0, 'RP-rod-8-out', 6, 59), (-1.0, 
        'RP-0', 6, 59)))
    mdb.models[ModelName].Equation(name='Constraint-68', terms=((1.0, 
        'RP-red-8-out-1', 1, 59), (-1.0, 'RP-rod-8-in-1', 1, 59), (-1.0, 'RP-0', 1, 
        59)))
    mdb.models[ModelName].Constraint(name='Constraint-68-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-68'])
    mdb.models[ModelName].constraints['Constraint-68-Copy'].setValues(
        terms=((1.0, 'RP-red-8-out-1', 2, 59), (-1.0, 'RP-rod-8-in-1', 2, 59), (
        -1.0, 'RP-0', 2, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-68-Copy-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-68-Copy'])
    mdb.models[ModelName].constraints['Constraint-68-Copy-Copy'].setValues(
        terms=((1.0, 'RP-red-8-out-1', 6, 59), (-1.0, 'RP-rod-8-in-1', 6, 59), (
        -1.0, 'RP-0', 6, 59)))
    mdb.models[ModelName].Equation(name='Constraint-71', terms=((1.0, 
        'RP-rod-8-in-1', 1, 59), (-1.0, 'RP-rod-8-out-1', 1, 59), (-1.0, 'RP-0', 1, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-71-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-71'])
    mdb.models[ModelName].constraints['Constraint-71-Copy'].setValues(
        terms=((1.0, 'RP-rod-8-in-1', 2, 59), (-1.0, 'RP-rod-8-out-1', 2, 59), (
        -1.0, 'RP-0', 2, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-71-Copy-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-71-Copy'])
    mdb.models[ModelName].constraints['Constraint-71-Copy-Copy'].setValues(
        terms=((1.0, 'RP-rod-8-in-1', 6, 59), (-1.0, 'RP-rod-8-out-1', 6, 59), (
        -1.0, 'RP-0', 6, 59)))
        
    session.viewports['Viewport: 1'].view.setValues(nearPlane=346.345, 
        farPlane=353.273, width=16.033, height=11.3683, viewOffsetX=-29.2378, 
        viewOffsetY=71.9894)
    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=('[#0:9 #2000000 ]', ), )
    a.Set(nodes=nodes1, name='rod-out-top-0')
    #: The set 'rod-out-top-0' has been created (1 node).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=347.554, 
        farPlane=352.064, width=10.4334, height=7.39782, viewOffsetX=-24.9968, 
        viewOffsetY=68.4275)
    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=('[#0:10 #1 ]', ), )
    a.Set(nodes=nodes1, name='rod-out-top-1')
    #: The set 'rod-out-top-1' has been created (1 node).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=346.592, 
        farPlane=353.026, width=14.8887, height=10.5569, viewOffsetX=-29.9436, 
        viewOffsetY=51.552)
    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=('[#0:9 #200000 ]', ), )
    a.Set(nodes=nodes1, name='rod-out-top-2-1')
    #: The set 'rod-out-top-2-1' has been created (1 node).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=347.403, 
        farPlane=352.215, width=11.1328, height=7.89376, viewOffsetX=-13.4705, 
        viewOffsetY=48.9948)
    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=('[#10 ]', ), )
    a.Set(nodes=nodes1, name='rod-out-top-2-2')
    #: The set 'rod-out-top-2-2' has been created (1 node).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=345.408, 
        farPlane=354.21, width=20.3705, height=14.4438, viewOffsetX=-4.02806, 
        viewOffsetY=35.0691)
    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=('[#0:10 #40 ]', ), )
    a.Set(nodes=nodes1, name='rod-out-top-3')
    #: The set 'rod-out-top-3' has been created (1 node).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=343.94, 
        farPlane=355.678, width=27.1735, height=19.2675, viewOffsetX=-23.2791, 
        viewOffsetY=16.3425)
    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=('[#0:2 #4000000 ]', ), )
    a.Set(nodes=nodes1, name='rod-out-top-4')
    #: The set 'rod-out-top-4' has been created (1 node).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=346.118, 
        farPlane=353.5, width=17.0824, height=12.1123, viewOffsetX=8.41062, 
        viewOffsetY=12.1518)
    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=('[#0 #1000000 ]', ), )
    a.Set(nodes=nodes1, name='rod-out-top-4-2')
    #: The set 'rod-out-top-4-2' has been created (1 node).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=345.186, 
        farPlane=354.432, width=21.366, height=15.1497, viewOffsetX=23.4038, 
        viewOffsetY=-5.48525)
    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=('[#200000 ]', ), )
    a.Set(nodes=nodes1, name='rod-out-top-5')
    #: The set 'rod-out-top-5' has been created (1 node).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=343.849, 
        farPlane=355.769, width=27.5944, height=19.5659, viewOffsetX=-22.8209, 
        viewOffsetY=-18.8866)
    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=('[#0:4 #4000000 ]', ), )
    a.Set(nodes=nodes1, name='rod-out-top-6')
    #: The set 'rod-out-top-6' has been created (1 node).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=347.337, 
        farPlane=352.281, width=11.4375, height=8.10979, viewOffsetX=25.6998, 
        viewOffsetY=-21.2539)
    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=('[#0:10 #1000 ]', ), )
    a.Set(nodes=nodes1, name='rod-out-top-6-2')
    #: The set 'rod-out-top-6-2' has been created (1 node).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=345.802, 
        farPlane=353.816, width=18.5476, height=13.1512, viewOffsetX=-26.9723, 
        viewOffsetY=-57.0905)
    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=('[#0:9 #1000 ]', ), )
    a.Set(nodes=nodes1, name='rod-out-top-7')
    #: The set 'rod-out-top-7' has been created (1 node).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=347.199, 
        farPlane=352.419, width=12.0756, height=8.56224, viewOffsetX=-27.9624, 
        viewOffsetY=73.3996)
    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=('[#0:9 #800000 ]', ), )
    a.Set(nodes=nodes1, name='rod-out-bo-0')
    #: The set 'rod-out-bo-0' has been created (1 node).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=346.206, 
        farPlane=353.412, width=16.6769, height=11.8249, viewOffsetX=-16.055, 
        viewOffsetY=56.7846)
    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=('[#0:10 #8 ]', ), )
    a.Set(nodes=nodes1, name='rod-out-bo-1')
    #: The set 'rod-out-bo-1' has been created (1 node).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=347.396, 
        farPlane=352.222, width=11.1664, height=7.91759, viewOffsetX=-29.9849, 
        viewOffsetY=38.6505)
    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=('[#0:9 #40000 ]', ), )
    a.Set(nodes=nodes1, name='rod-out-bo-2-1')
    #: The set 'rod-out-bo-2-1' has been created (1 node).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=346.38, 
        farPlane=353.237, width=15.8674, height=11.2509, viewOffsetX=-5.91249, 
        viewOffsetY=39.4825)
    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=('[#2000 ]', ), )
    a.Set(nodes=nodes1, name='rod-out-bo-2-2')
    #: The set 'rod-out-bo-2-2' has been created (1 node).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=345.538, 
        farPlane=354.08, width=19.7707, height=14.0185, viewOffsetX=6.09574, 
        viewOffsetY=21.9566)
    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=('[#0:10 #200 ]', ), )
    a.Set(nodes=nodes1, name='rod-out-bo-3')
    #: The set 'rod-out-bo-3' has been created (1 node).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=343.402, 
        farPlane=356.216, width=29.6684, height=21.0365, viewOffsetX=-22.5891, 
        viewOffsetY=2.00471)
    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=('[#0:2 #80000 ]', ), )
    a.Set(nodes=nodes1, name='rod-out-bo-4')
    #: The set 'rod-out-bo-4' has been created (1 node).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=345.955, 
        farPlane=353.663, width=17.8399, height=12.6494, viewOffsetX=14.0838, 
        viewOffsetY=3.76922)
    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=('[#0:2 #2 ]', ), )
    a.Set(nodes=nodes1, name='rod-out-bo-4-2')
    #: The set 'rod-out-bo-4-2' has been created (1 node).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=347.194, 
        farPlane=352.424, width=12.101, height=8.58026, viewOffsetX=24.0846, 
        viewOffsetY=-14.3933)
    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=('[#20000000 ]', ), )
    a.Set(nodes=nodes1, name='rod-out-bo-5')
    #: The set 'rod-out-bo-5' has been created (1 node).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=345.937, 
        farPlane=353.681, width=17.9202, height=12.7064, viewOffsetX=-27.7195, 
        viewOffsetY=-34.2864)
    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=('[#0:4 #80000 ]', ), )
    a.Set(nodes=nodes1, name='rod-out-bo-6')
    #: The set 'rod-out-bo-6' has been created (1 node).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=342.309, 
        farPlane=357.309, width=34.7364, height=24.63, viewOffsetX=38.8835, 
        viewOffsetY=-31.1228)
    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=('[#0:10 #4000 ]', ), )
    a.Set(nodes=nodes1, name='rod-out-bo-6-2')
    #: The set 'rod-out-bo-6-2' has been created (1 node).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=344.261, 
        farPlane=355.357, width=25.6849, height=18.212, viewOffsetX=-23.0109, 
        viewOffsetY=-69.3225)
    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=('[#0:9 #4000 ]', ), )
    a.Set(nodes=nodes1, name='rod-out-bo-7')
    #: The set 'rod-out-bo-7' has been created (1 node).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=347.346, 
        farPlane=352.272, width=12.8855, height=9.13652, viewOffsetX=-28.3826, 
        viewOffsetY=73.4832)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-2-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#4 ]', ), )
    a.Set(vertices=verts1, name='rod-in-bo-0')
    #: The set 'rod-in-bo-0' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=345.906, 
        farPlane=353.712, width=18.0652, height=12.8092, viewOffsetX=-18.6392, 
        viewOffsetY=58.9721)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-3-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#20000000 ]', ), )
    a.Set(vertices=verts1, name='rod-in-bo-1')
    #: The set 'rod-in-bo-1' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=343.584, 
        farPlane=356.034, width=28.8239, height=20.4377, viewOffsetX=-23.2862, 
        viewOffsetY=40.3552)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-2-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#40000000 ]', ), )
    a.Set(vertices=verts1, name='rod-in-bo-2-1')
    #: The set 'rod-in-bo-2-1' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=345.086, 
        farPlane=354.532, width=21.8624, height=15.5016, viewOffsetX=-6.18524, 
        viewOffsetY=41.5967)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-3-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#200000 ]', ), )
    a.Set(vertices=verts1, name='rod-in-bo-2-2')
    #: The set 'rod-in-bo-2-2' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=343.146, 
        farPlane=356.472, width=30.856, height=21.8786, viewOffsetX=8.73798, 
        viewOffsetY=24.9571)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-2-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#40 ]', ), )
    a.Set(vertices=verts1, name='rod-in-bo-3')
    #: The set 'rod-in-bo-3' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=340.468, 
        farPlane=359.15, width=43.2768, height=30.6856, viewOffsetX=-13.5057, 
        viewOffsetY=6.99675)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-2-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#4000000 ]', ), )
    a.Set(vertices=verts1, name='rod-in-bo-4')
    #: The set 'rod-in-bo-4' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=346.645, 
        farPlane=352.973, width=14.6448, height=10.384, viewOffsetX=11.4839, 
        viewOffsetY=4.28654)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-3-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#4000 ]', ), )
    a.Set(vertices=verts1, name='rod-in-bo-4-2')
    #: The set 'rod-in-bo-4-2' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=344.881, 
        farPlane=354.737, width=22.8127, height=16.1755, viewOffsetX=23.5707, 
        viewOffsetY=-9.74969)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-3-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#100 ]', ), )
    a.Set(vertices=verts1, name='rod-in-bo-5')
    #: The set 'rod-in-bo-5' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=344.946, 
        farPlane=354.672, width=22.5126, height=15.9627, viewOffsetX=-23.6745, 
        viewOffsetY=-33.7637)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-2-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#100000 ]', ), )
    a.Set(vertices=verts1, name='rod-in-bo-6')
    #: The set 'rod-in-bo-6' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=344.091, 
        farPlane=355.527, width=26.4742, height=18.7717, viewOffsetX=36.6751, 
        viewOffsetY=-28.172)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-2-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#400 ]', ), )
    a.Set(vertices=verts1, name='rod-in-bo-6-2')
    #: The set 'rod-in-bo-6-2' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=347.421, 
        farPlane=352.197, width=11.0516, height=7.83621, viewOffsetX=-29.6609, 
        viewOffsetY=-69.0019)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-2-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#1000 ]', ), )
    a.Set(vertices=verts1, name='rod-in-bo-7')
    #: The set 'rod-in-bo-7' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=347.02, 
        farPlane=352.598, width=12.9071, height=9.15184, viewOffsetX=-30.3134, 
        viewOffsetY=74.9612)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-2-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#2 ]', ), )
    a.Set(vertices=verts1, name='rod-in-top-0')
    #: The set 'rod-in-top-0' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=347.564, 
        farPlane=352.053, width=10.3856, height=7.36398, viewOffsetX=-24.9789, 
        viewOffsetY=67.1355)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-3-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#10000000 ]', ), )
    a.Set(vertices=verts1, name='rod-in-top-1')
    #: The set 'rod-in-top-1' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=341.762, 
        farPlane=357.856, width=37.2724, height=26.4282, viewOffsetX=-21.4235, 
        viewOffsetY=53.753)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-2-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#0 #1 ]', ), )
    a.Set(vertices=verts1, name='rod-in-top-2-1')
    #: The set 'rod-in-top-2-1' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=345.898, 
        farPlane=353.72, width=18.1006, height=12.8343, viewOffsetX=-13.8825, 
        viewOffsetY=50.1571)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-3-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#100000 ]', ), )
    a.Set(vertices=verts1, name='rod-in-top-2-2')
    #: The set 'rod-in-top-2-2' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=345.907, 
        farPlane=353.711, width=18.0598, height=12.8054, viewOffsetX=-2.57407, 
        viewOffsetY=31.3278)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-2-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#20 ]', ), )
    a.Set(vertices=verts1, name='rod-in-top-3')
    #: The set 'rod-in-top-3' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=345.237, 
        farPlane=354.381, width=21.1628, height=15.0056, viewOffsetX=-26.5923, 
        viewOffsetY=15.6353)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-2-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#10000000 ]', ), )
    a.Set(vertices=verts1, name='rod-in-top-4')
    #: The set 'rod-in-top-4' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=347.237, 
        farPlane=352.381, width=11.9006, height=8.43816, viewOffsetX=6.93733, 
        viewOffsetY=13.678)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-3-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#2000 ]', ), )
    a.Set(vertices=verts1, name='rod-in-top-4-2')
    #: The set 'rod-in-top-4-2' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=346.214, 
        farPlane=353.404, width=16.6364, height=11.7961, viewOffsetX=9.71751, 
        viewOffsetY=14.5548)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-3-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#80 ]', ), )
    a.Set(vertices=verts1, name='rod-in-top-5')
    #: The set 'rod-in-top-5' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=337.108, 
        farPlane=362.51, width=58.881, height=41.7498, viewOffsetX=-8.43567, 
        viewOffsetY=-13.3742)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-2-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#400000 ]', ), )
    a.Set(vertices=verts1, name='rod-in-top-6')
    #: The set 'rod-in-top-6' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=343.095, 
        farPlane=356.523, width=31.0932, height=22.0468, viewOffsetX=27.1274, 
        viewOffsetY=-17.9843)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-2-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#200 ]', ), )
    a.Set(vertices=verts1, name='rod-in-top-6-2')
    #: The set 'rod-in-top-6-2' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=345.206, 
        farPlane=354.412, width=21.306, height=15.1071, viewOffsetX=-27.8203, 
        viewOffsetY=-53.4827)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-2-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#4000 ]', ), )
    a.Set(vertices=verts1, name='rod-in-top-7')
    #: The set 'rod-in-top-7' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=348.106, 
        farPlane=351.512, width=7.88104, height=5.58809, viewOffsetX=-20.016, 
        viewOffsetY=58.6288)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-3-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#2000000 ]', ), )
    a.Set(vertices=verts1, name='red-in-bo-1')
    #: The set 'red-in-bo-1' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=348.827, 
        farPlane=350.791, width=4.54366, height=3.22171, viewOffsetX=-20.3238, 
        viewOffsetY=58.2775)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-3-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#2000000 ]', ), )
    a.Set(vertices=verts1, name='red-in-bo-2-2')
    #: The set 'red-in-bo-2-2' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=347.426, 
        farPlane=352.192, width=11.0276, height=7.81918, viewOffsetX=-7.87174, 
        viewOffsetY=41.4707)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-3-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#800000 ]', ), )
    a.Set(vertices=verts1, name='red-in-bo-2-2')
    #: The set 'red-in-bo-2-2' has been edited (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=348.266, 
        farPlane=351.352, width=7.13883, height=5.06182, viewOffsetX=12.4367, 
        viewOffsetY=3.92212)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-3-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#40000 ]', ), )
    a.Set(vertices=verts1, name='red-in-bo-4-2')
    #: The set 'red-in-bo-4-2' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=348.12, 
        farPlane=351.498, width=7.81543, height=5.54156, viewOffsetX=22.3873, 
        viewOffsetY=-13.6144)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-3-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#400 ]', ), )
    a.Set(vertices=verts1, name='red-in-bo-5')
    #: The set 'red-in-bo-5' has been created (1 vertex).
    #: Warning: Cannot continue yet--complete the step or cancel the procedure.
    session.viewports['Viewport: 1'].view.setValues(nearPlane=348.098, 
        farPlane=351.52, width=7.91534, height=5.61241, viewOffsetX=-23.3305, 
        viewOffsetY=67.0615)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-3-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#4000000 ]', ), )
    a.Set(vertices=verts1, name='red-in-top-1')
    #: The set 'red-in-top-1' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=348.688, 
        farPlane=350.93, width=5.18646, height=3.67749, viewOffsetX=-13.941, 
        viewOffsetY=47.9115)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-3-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#1000000 ]', ), )
    a.Set(vertices=verts1, name='red-in-top-2-2')
    #: The set 'red-in-top-2-2' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=347.273, 
        farPlane=352.345, width=11.7357, height=8.32127, viewOffsetX=9.2181, 
        viewOffsetY=11.8753)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-3-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#10000 ]', ), )
    a.Set(vertices=verts1, name='red-in-top-4-2')
    #: The set 'red-in-top-4-2' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=348.375, 
        farPlane=351.243, width=6.63618, height=4.70541, viewOffsetX=17.3182, 
        viewOffsetY=-5.86095)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-3-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#800 ]', ), )
    a.Set(vertices=verts1, name='red-in-top-5')
    #: The set 'red-in-top-5' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=347.639, 
        farPlane=351.979, width=10.0401, height=7.11896, viewOffsetX=-18.5779, 
        viewOffsetY=58.2937)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-3-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#40000000 ]', ), )
    a.Set(vertices=verts1, name='red-out-bo-1')
    #: The set 'red-out-bo-1' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=346.81, 
        farPlane=352.808, width=13.8796, height=9.84141, viewOffsetX=-7.76049, 
        viewOffsetY=38.9851)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-3-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#400000 ]', ), )
    a.Set(vertices=verts1, name='red-out-bo-2-2')
    #: The set 'red-out-bo-2-2' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=347.744, 
        farPlane=351.874, width=9.55572, height=6.77553, viewOffsetX=12.6561, 
        viewOffsetY=4.24807)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-3-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#8000 ]', ), )
    a.Set(vertices=verts1, name='red-out-bo-4-2')
    #: The set 'red-out-bo-4-2' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=347.613, 
        farPlane=352.005, width=10.1612, height=7.20487, viewOffsetX=24.2519, 
        viewOffsetY=-14.6387)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-3-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#200 ]', ), )
    a.Set(vertices=verts1, name='red-out-bo-5')
    #: The set 'red-out-bo-5' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=347.871, 
        farPlane=351.747, width=8.96469, height=6.35645, viewOffsetX=7.21778, 
        viewOffsetY=13.1785)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-3-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#1000 ]', ), )
    a.Set(vertices=verts1, name='red-out-top-1')
    #: The set 'red-out-top-1' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=347.75, 
        farPlane=351.868, width=9.5275, height=6.75552, viewOffsetX=17.4331, 
        viewOffsetY=-6.3092)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-3-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#8000 ]', ), )
    a.Set(vertices=verts1, name='red-out-top-2-2')
    #: The set 'red-out-top-2-2' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=347.414, 
        farPlane=352.204, width=11.0838, height=7.85903, viewOffsetX=7.44569, 
        viewOffsetY=14.2643)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-3-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#1000 ]', ), )
    a.Set(vertices=verts1, name='red-out-top-4-2')
    #: The set 'red-out-top-4-2' has been created (1 vertex).
    session.viewports['Viewport: 1'].view.setValues(nearPlane=348.258, 
        farPlane=351.36, width=7.1753, height=5.08768, viewOffsetX=17.5748, 
        viewOffsetY=-5.95688)
    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-3-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#40 ]', ), )
    a.Set(vertices=verts1, name='red-out-top-5')
    #: The set 'red-out-top-5' has been created (1 vertex).




    mdb.models[ModelName].Equation(name='Constraint-74', terms=((1.0, 
        'rod-out-top-0', 1, 59), (1.0, 'rod-out-bo-0', 1, 59), (-1.0, 
        'rod-in-bo-0', 1, 59), (-1.0, 'rod-in-top-0', 1, 59)))
    session.viewports['Viewport: 1'].view.setValues(nearPlane=348.006, 
        farPlane=351.612, width=10.3352, height=5.62351, viewOffsetX=-34.7331, 
        viewOffsetY=73.5664)
    mdb.models[ModelName].Constraint(name='Constraint-74-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-74'])
    mdb.models[ModelName].constraints['Constraint-74-Copy'].setValues(
        terms=((1.0, 'rod-out-top-0', 2, 59), (1.0, 'rod-out-bo-0', 2, 59), (-1.0, 
        'rod-in-bo-0', 2, 59), (-1.0, 'rod-in-top-0', 2, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-74-Copy-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-74-Copy'])
    mdb.models[ModelName].constraints['Constraint-74-Copy-Copy'].setValues(
        terms=((1.0, 'rod-out-top-0', 6, 59), (1.0, 'rod-out-bo-0', 6, 59), (-1.0, 
        'rod-in-bo-0', 6, 59), (-1.0, 'rod-in-top-0', 6, 59)))
    session.viewports['Viewport: 1'].view.setValues(nearPlane=334.423, 
        farPlane=365.195, width=88.3932, height=48.0959, viewOffsetX=-29.9882, 
        viewOffsetY=63.3162)
    mdb.models[ModelName].Equation(name='Constraint-77', terms=((1.0, 
        'rod-out-bo-1', 1, 59), (1.0, 'rod-out-top-1', 1, 59), (-1.0, 
        'rod-in-bo-1', 1, 59), (-1.0, 'rod-in-top-1', 1, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-77-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-77'])
    mdb.models[ModelName].constraints['Constraint-77-Copy'].setValues(
        terms=((1.0, 'rod-out-bo-1', 2, 59), (1.0, 'rod-out-top-1', 2, 59), (-1.0, 
        'rod-in-bo-1', 2, 59), (-1.0, 'rod-in-top-1', 2, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-77-Copy-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-77-Copy'])
    mdb.models[ModelName].constraints['Constraint-77-Copy-Copy'].setValues(
        terms=((1.0, 'rod-out-bo-1', 6, 59), (1.0, 'rod-out-top-1', 6, 59), (-1.0, 
        'rod-in-bo-1', 6, 59), (-1.0, 'rod-in-top-1', 6, 59)))
    session.viewports['Viewport: 1'].view.setValues(nearPlane=342.871, 
        farPlane=356.747, width=44.9282, height=24.446, viewOffsetX=-26.8216, 
        viewOffsetY=58.1536)
    mdb.models[ModelName].Equation(name='Constraint-80', terms=((1.0, 
        'red-out-bo-1', 1, 59), (1.0, 'red-out-top-1', 1, 59), (-1.0, 
        'red-in-bo-1', 1, 59), (-1.0, 'red-in-top-1', 1, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-80-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-80'])
    mdb.models[ModelName].constraints['Constraint-80-Copy'].setValues(
        terms=((1.0, 'red-out-bo-1', 2, 59), (1.0, 'red-out-top-1', 2, 59), (-1.0, 
        'red-in-bo-1', 2, 59), (-1.0, 'red-in-top-1', 2, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-80-Copy-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-80-Copy'])
    mdb.models[ModelName].constraints['Constraint-80-Copy-Copy'].setValues(
        terms=((1.0, 'red-out-bo-1', 6, 59), (1.0, 'red-out-top-1', 6, 59), (-1.0, 
        'red-in-bo-1', 6, 59), (-1.0, 'red-in-top-1', 6, 59)))
    session.viewports['Viewport: 1'].view.setValues(nearPlane=329.379, 
        farPlane=370.238, width=131.994, height=71.8199, viewOffsetX=-42.3652, 
        viewOffsetY=54.1727)
    mdb.models[ModelName].Equation(name='Constraint-83', terms=((1.0, 
        'rod-out-bo-2-1', 1, 59), (1.0, 'rod-out-top-2-1', 1, 59), (-1.0, 
        'rod-in-top-2-1', 1, 59), (-1.0, 'rod-in-bo-2-1', 1, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-83-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-83'])
    mdb.models[ModelName].constraints['Constraint-83-Copy'].setValues(
        terms=((1.0, 'rod-out-bo-2-1', 2, 59), (1.0, 'rod-out-top-2-1', 2, 59), (
        -1.0, 'rod-in-top-2-1', 2, 59), (-1.0, 'rod-in-bo-2-1', 2, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-83-Copy-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-83-Copy'])
    mdb.models[ModelName].constraints['Constraint-83-Copy-Copy'].setValues(
        terms=((1.0, 'rod-out-bo-2-1', 6, 59), (1.0, 'rod-out-top-2-1', 6, 59), (
        -1.0, 'rod-in-top-2-1', 6, 59), (-1.0, 'rod-in-bo-2-1', 6, 59)))
    session.viewports['Viewport: 1'].view.setValues(nearPlane=339.006, 
        farPlane=360.612, width=69.9141, height=38.0412, viewOffsetX=-38.7866, 
        viewOffsetY=51.794)
    mdb.models[ModelName].Equation(name='Constraint-86', terms=((1.0, 
        'rod-out-bo-2-2', 1, 59), (1.0, 'rod-out-top-2-2', 1, 59), (-1.0, 
        'rod-in-top-2-2', 1, 59), (-1.0, 'rod-in-bo-2-2', 1, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-86-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-86'])
    mdb.models[ModelName].constraints['Constraint-86-Copy'].setValues(
        terms=((1.0, 'rod-out-bo-2-2', 2, 59), (1.0, 'rod-out-top-2-2', 2, 59), (
        -1.0, 'rod-in-top-2-2', 2, 59), (-1.0, 'rod-in-bo-2-2', 2, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-86-Copy-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-86-Copy'])
    mdb.models[ModelName].constraints['Constraint-86-Copy-Copy'].setValues(
        terms=((1.0, 'rod-out-bo-2-2', 6, 59), (1.0, 'rod-out-top-2-2', 6, 59), (
        -1.0, 'rod-in-top-2-2', 6, 59), (-1.0, 'rod-in-bo-2-2', 6, 59)))
    session.viewports['Viewport: 1'].view.setValues(nearPlane=342.288, 
        farPlane=357.33, width=48.6987, height=26.4958, viewOffsetX=-23.1993, 
        viewOffsetY=43.5823)
    mdb.models[ModelName].Equation(name='Constraint-89', terms=((1.0, 
        'red-out-bo-2-2', 1, 59), (1.0, 'red-out-top-2-2', 1, 59), (-1.0, 
        'red-in-bo-2-2', 1, 59), (-1.0, 'red-in-top-2-2', 1, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-89-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-89'])
    mdb.models[ModelName].constraints['Constraint-89-Copy'].setValues(
        terms=((1.0, 'red-out-bo-2-2', 2, 59), (1.0, 'red-out-top-2-2', 2, 59), (
        -1.0, 'red-in-bo-2-2', 2, 59), (-1.0, 'red-in-top-2-2', 2, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-89-Copy-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-89-Copy'])
    mdb.models[ModelName].constraints['Constraint-89-Copy-Copy'].setValues(
        terms=((1.0, 'red-out-bo-2-2', 6, 59), (1.0, 'red-out-top-2-2', 6, 59), (
        -1.0, 'red-in-bo-2-2', 6, 59), (-1.0, 'red-in-top-2-2', 6, 59)))
    session.viewports['Viewport: 1'].view.setValues(nearPlane=323.648, 
        farPlane=375.97, width=168.855, height=91.8582, viewOffsetX=-37.0878, 
        viewOffsetY=34.7825)
    mdb.models[ModelName].Equation(name='Constraint-92', terms=((1.0, 
        'rod-out-bo-3', 1, 59), (1.0, 'rod-out-top-3', 1, 59), (-1.0, 
        'rod-in-top-3', 1, 59), (-1.0, 'rod-in-bo-3', 1, 59)))
    session.viewports['Viewport: 1'].view.setValues(nearPlane=322.349, 
        farPlane=377.269, width=158.087, height=86.0171, viewOffsetX=-39.0618, 
        viewOffsetY=9.61628)
    mdb.models[ModelName].Constraint(name='Constraint-92-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-92'])
    mdb.models[ModelName].constraints['Constraint-92-Copy'].setValues(
        terms=((1.0, 'rod-out-bo-3', 2, 59), (1.0, 'rod-out-top-3', 2, 59), (-1.0, 
        'rod-in-top-3', 2, 59), (-1.0, 'rod-in-bo-3', 2, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-92-Copy-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-92-Copy'])
    mdb.models[ModelName].constraints['Constraint-92-Copy-Copy'].setValues(
        terms=((1.0, 'rod-out-bo-3', 6, 59), (1.0, 'rod-out-top-3', 6, 59), (-1.0, 
        'rod-in-top-3', 6, 59), (-1.0, 'rod-in-bo-3', 6, 59)))
    mdb.models[ModelName].Equation(name='Constraint-95', terms=((1.0, 
        'rod-out-bo-4', 1, 59), (1.0, 'rod-out-top-4', 1, 59), (-1.0, 
        'rod-in-top-4', 1, 59), (-1.0, 'rod-in-bo-4', 1, 59)))
    session.viewports['Viewport: 1'].view.setValues(nearPlane=345.196, 
        farPlane=354.422, width=26.4527, height=14.3933, viewOffsetX=-35.3129, 
        viewOffsetY=11.4517)
    mdb.models[ModelName].Constraint(name='Constraint-95-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-95'])
    mdb.models[ModelName].constraints['Constraint-95-Copy'].setValues(
        terms=((1.0, 'rod-out-bo-4', 2, 59), (1.0, 'rod-out-top-4', 2, 59), (-1.0, 
        'rod-in-top-4', 2, 59), (-1.0, 'rod-in-bo-4', 2, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-95-Copy-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-95-Copy'])
    mdb.models[ModelName].constraints['Constraint-95-Copy-Copy'].setValues(
        terms=((1.0, 'rod-out-bo-4', 6, 59), (1.0, 'rod-out-top-4', 6, 59), (-1.0, 
        'rod-in-top-4', 6, 59), (-1.0, 'rod-in-bo-4', 6, 59)))
    session.viewports['Viewport: 1'].view.setValues(nearPlane=342.692, 
        farPlane=356.926, width=40.8281, height=22.2151, viewOffsetX=0.584412, 
        viewOffsetY=5.86449)
    mdb.models[ModelName].Equation(name='Constraint-98', terms=((1.0, 
        'rod-out-bo-4-2', 1, 59), (1.0, 'rod-out-top-4-2', 1, 59), (-1.0, 
        'rod-in-top-4-2', 1, 59), (-1.0, 'rod-in-bo-4-2', 1, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-98-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-98'])
    mdb.models[ModelName].constraints['Constraint-98-Copy'].setValues(
        terms=((1.0, 'rod-out-bo-4-2', 2, 59), (1.0, 'rod-out-top-4-2', 2, 59), (
        -1.0, 'rod-in-top-4-2', 2, 59), (-1.0, 'rod-in-bo-4-2', 2, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-98-Copy-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-98-Copy'])
    mdb.models[ModelName].constraints['Constraint-98-Copy-Copy'].setValues(
        terms=((1.0, 'rod-out-bo-4-2', 6, 59), (1.0, 'rod-out-top-4-2', 6, 59), (
        -1.0, 'rod-in-top-4-2', 6, 59), (-1.0, 'rod-in-bo-4-2', 6, 59)))
    session.viewports['Viewport: 1'].view.setValues(nearPlane=339.469, 
        farPlane=360.149, width=59.3483, height=32.2922, viewOffsetX=-1.78686, 
        viewOffsetY=5.84201)
    mdb.models[ModelName].Equation(name='Constraint-101', terms=((1.0, 
        'red-out-bo-4-2', 1, 59), (1.0, 'red-out-top-4-2', 1, 59), (-1.0, 
        'red-in-top-4-2', 1, 59), (-1.0, 'red-in-bo-4-2', 1, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-101-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-101'])
    mdb.models[ModelName].constraints['Constraint-101-Copy'].setValues(
        terms=((1.0, 'red-out-bo-4-2', 2, 59), (1.0, 'red-out-top-4-2', 2, 59), (
        -1.0, 'red-in-top-4-2', 2, 59), (-1.0, 'red-in-bo-4-2', 2, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-101-Copy-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-101-Copy'])
    mdb.models[ModelName].constraints['Constraint-101-Copy-Copy'].setValues(
        terms=((1.0, 'red-out-bo-4-2', 6, 59), (1.0, 'red-out-top-4-2', 6, 59), (
        -1.0, 'red-in-top-4-2', 6, 59), (-1.0, 'red-in-bo-4-2', 6, 59)))
    session.viewports['Viewport: 1'].view.setValues(nearPlane=317.701, 
        farPlane=381.917, width=207.03, height=112.648, viewOffsetX=-28.381, 
        viewOffsetY=-3.49347)
    mdb.models[ModelName].Equation(name='Constraint-104', terms=((1.0, 
        'rod-out-top-5', 1, 59), (1.0, 'rod-out-bo-5', 1, 59), (-1.0, 
        'rod-in-top-5', 1, 59), (-1.0, 'rod-in-bo-5', 1, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-104-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-104'])
    mdb.models[ModelName].constraints['Constraint-104-Copy'].setValues(
        terms=((1.0, 'rod-out-top-5', 2, 59), (1.0, 'rod-out-bo-5', 2, 59), (-1.0, 
        'rod-in-top-5', 2, 59), (-1.0, 'rod-in-bo-5', 2, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-104-Copy-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-104-Copy'])
    mdb.models[ModelName].constraints['Constraint-104-Copy-Copy'].setValues(
        terms=((1.0, 'rod-out-top-5', 6, 59), (1.0, 'rod-out-bo-5', 6, 59), (-1.0, 
        'rod-in-top-5', 6, 59), (-1.0, 'rod-in-bo-5', 6, 59)))
    mdb.models[ModelName].Equation(name='Constraint-107', terms=((1.0, 
        'rod-out-top-6', 1, 59), (1.0, 'rod-out-bo-6', 1, 59), (-1.0, 
        'rod-in-top-6', 1, 59), (-1.0, 'rod-in-bo-6', 1, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-107-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-107'])
    mdb.models[ModelName].constraints['Constraint-107-Copy'].setValues(
        terms=((1.0, 'rod-out-top-6', 2, 59), (1.0, 'rod-out-bo-6', 2, 59), (-1.0, 
        'rod-in-top-6', 2, 59), (-1.0, 'rod-in-bo-6', 2, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-107-Copy-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-107-Copy'])
    mdb.models[ModelName].constraints['Constraint-107-Copy-Copy'].setValues(
        terms=((1.0, 'rod-out-top-6', 6, 59), (1.0, 'rod-out-bo-6', 6, 59), (-1.0, 
        'rod-in-top-6', 6, 59), (-1.0, 'rod-in-bo-6', 6, 59)))
    session.viewports['Viewport: 1'].view.setValues(nearPlane=323.788, 
        farPlane=375.83, width=149.78, height=81.4975, viewOffsetX=-5.31569, 
        viewOffsetY=-15.4038)
    mdb.models[ModelName].Equation(name='Constraint-110', terms=((1.0, 
        'rod-out-top-6-2', 1, 59), (1.0, 'rod-out-bo-6-2', 1, 59), (-1.0, 
        'rod-in-top-6-2', 1, 59), (-1.0, 'rod-in-bo-6-2', 1, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-110-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-110'])
    mdb.models[ModelName].constraints['Constraint-110-Copy'].setValues(
        terms=((1.0, 'rod-out-top-6-2', 2, 59), (1.0, 'rod-out-bo-6-2', 2, 59), (
        -1.0, 'rod-in-top-6-2', 2, 59), (-1.0, 'rod-in-bo-6-2', 2, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-110-Copy-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-110-Copy'])
    mdb.models[ModelName].constraints['Constraint-110-Copy-Copy'].setValues(
        terms=((1.0, 'rod-out-top-6-2', 6, 59), (1.0, 'rod-out-bo-6-2', 6, 59), (
        -1.0, 'rod-in-top-6-2', 6, 59), (-1.0, 'rod-in-bo-6-2', 6, 59)))
    session.viewports['Viewport: 1'].view.setValues(nearPlane=318.973, 
        farPlane=380.645, width=177.65, height=96.6616, viewOffsetX=-33.912, 
        viewOffsetY=-39.3806)
    mdb.models[ModelName].Equation(name='Constraint-113', terms=((1.0, 
        'rod-out-top-7', 1, 59), (1.0, 'rod-out-bo-7', 1, 59), (-1.0, 
        'rod-in-top-7', 1, 59), (-1.0, 'rod-in-bo-7', 1, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-113-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-113'])
    mdb.models[ModelName].constraints['Constraint-113-Copy'].setValues(
        terms=((1.0, 'rod-out-top-7', 2, 59), (1.0, 'rod-out-bo-7', 2, 59), (-1.0, 
        'rod-in-top-7', 2, 59), (-1.0, 'rod-in-bo-7', 2, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-113-Copy-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-113-Copy'])
    mdb.models[ModelName].constraints['Constraint-113-Copy-Copy'].setValues(
        terms=((1.0, 'rod-out-top-7', 6, 59), (1.0, 'rod-out-bo-7', 6, 59), (-1.0, 
        'rod-in-top-7', 6, 59), (-1.0, 'rod-in-bo-7', 6, 59)))
    mdb.models[ModelName].Equation(name='Constraint-116', terms=((1.0, 
        'red-out-top-5', 1, 59), (1.0, 'red-out-bo-5', 1, 59), (-1.0, 
        'red-in-top-5', 1, 59), (-1.0, 'red-in-bo-5', 1, 59)))
    mdb.models[ModelName].Equation(name='Constraint-116', terms=((1.0, 
        'red-out-top-5', 2, 59), (1.0, 'red-out-bo-5', 2, 59), (-1.0, 
        'red-in-top-5', 2, 59), (-1.0, 'red-in-bo-5', 2, 59)))
    mdb.models[ModelName].Equation(name='Constraint-116', terms=((1.0, 
        'red-out-top-5', 6, 59), (1.0, 'red-out-bo-5', 6, 59), (-1.0, 
        'red-in-top-5', 6, 59), (-1.0, 'red-in-bo-5', 6, 59)))
    mdb.models[ModelName].Constraint(name='Constraint-116-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-116'])
    mdb.models[ModelName].Constraint(name='Constraint-116-Copy-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-116-Copy'])
    mdb.models[ModelName].constraints['Constraint-116-Copy'].setValues(terms=(
        (1.0, 'red-out-top-5', 2, 59), (1.0, 'red-out-bo-5', 2, 59), (-1.0, 
        'red-in-top-5', 2, 59), (-1.0, 'red-in-bo-5', 2, 59)))
    mdb.models[ModelName].constraints['Constraint-116-Copy-Copy'].setValues(
        terms=((1.0, 'red-out-top-5', 1, 59), (1.0, 'red-out-bo-5', 1, 59), (-1.0, 
        'red-in-top-5', 1, 59), (-1.0, 'red-in-bo-5', 1, 59)))    
        
        

    mdb.models[ModelName].steps['Step-int'].suppress()
        
    mdb.models[ModelName].ContactProperty('IntProp-1')
    mdb.models[ModelName].interactionProperties['IntProp-1'].TangentialBehavior(
        formulation=FRICTIONLESS)
    mdb.models[ModelName].interactionProperties['IntProp-1'].NormalBehavior(
        pressureOverclosure=HARD, allowSeparation=ON, 
        constraintEnforcementMethod=DEFAULT)
    mdb.models[ModelName].interactionProperties['IntProp-1'].ThermalConductance(
        definition=USER_DEFINED)
    mdb.models[ModelName].interactionProperties['IntProp-1'].GeometricProperties(
        contactArea=1500.0, padThickness=None)
    #: The interaction property "IntProp-1" has been created.

    del mdb.models[ModelName].interactions['SURFFILM-1']

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-2-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#21858888 #56 ]', ), )
    region=regionToolset.Region(side1Edges=side1Edges1)
    mdb.models[ModelName].FilmCondition(name='Int-1', 
        createStepName='Step-1', surface=region, definition=EMBEDDED_COEFF, 
        filmCoeff=10.0, filmCoeffAmplitude='', sinkTemperature=948.0, 
        sinkAmplitude='', sinkDistributionType=UNIFORM, sinkFieldName='')
            
            
    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-2-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#2 ]', ), )
    region1=regionToolset.Region(side1Edges=side1Edges1)
    a = mdb.models[ModelName].rootAssembly
    f1 = a.instances['PART-1-1'].elements
    face2Elements1 = f1.getSequenceFromMask(mask=('[#0:659 #10842108 #10842 ]', ), 
        )
    region2=regionToolset.Region(face2Elements=face2Elements1)
    mdb.models[ModelName].SurfaceToSurfaceContactStd(name='Int-2', 
        createStepName='Step-1', master=region1, slave=region2, sliding=FINITE, 
        thickness=ON, interactionProperty='IntProp-1', adjustMethod=NONE, 
        initialClearance=OMIT, datumAxis=None, clearanceRegion=None)
    #: The interaction "Int-2" has been created.

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#4000000 ]', ), )
    region1=regionToolset.Region(side1Edges=side1Edges1)
    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#40000000 ]', ), )
    region2=regionToolset.Region(side1Edges=side1Edges1)
    mdb.models[ModelName].SurfaceToSurfaceContactStd(name='Int-3', 
        createStepName='Step-1', master=region1, slave=region2, sliding=FINITE, 
        thickness=ON, interactionProperty='IntProp-1', adjustMethod=NONE, 
        initialClearance=OMIT, datumAxis=None, clearanceRegion=None)
    #: The interaction "Int-3" has been created.

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#10000000 ]', ), )
    region1=regionToolset.Region(side1Edges=side1Edges1)
    a = mdb.models[ModelName].rootAssembly
    f1 = a.instances['PART-1-1'].elements
    face2Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:660 #84200000 #21084210 #8421084 #42108421 #10842108 #84210842', 
        ' #210 ]', ), )
    face4Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:666 #42108400 #10842108 #84210842 ]', ), )
    region2=regionToolset.Region(face2Elements=face2Elements1, 
        face4Elements=face4Elements1)
    mdb.models[ModelName].SurfaceToSurfaceContactStd(name='Int-4', 
        createStepName='Step-1', master=region1, slave=region2, sliding=FINITE, 
        thickness=ON, interactionProperty='IntProp-1', adjustMethod=NONE, 
        initialClearance=OMIT, datumAxis=None, clearanceRegion=None)
    #: The interaction "Int-4" has been created.

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-2-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#c0000000 ]', ), )
    region1=regionToolset.Region(side1Edges=side1Edges1)
    a = mdb.models[ModelName].rootAssembly
    f1 = a.instances['PART-1-1'].elements
    face2Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:647 #10400000 #4104104 #41041041 #10410410 #4104104 #41041041', 
        ' #10 ]', ), )
    face4Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:653 #20820820 #8208208 #82082082 #20820820 #8208208 #2082082 ]', ), )
    region2=regionToolset.Region(face2Elements=face2Elements1, 
        face4Elements=face4Elements1)
    mdb.models[ModelName].SurfaceToSurfaceContactStd(name='Int-5', 
        createStepName='Step-1', master=region1, slave=region2, sliding=FINITE, 
        thickness=ON, interactionProperty='IntProp-1', adjustMethod=NONE, 
        initialClearance=OMIT, datumAxis=None, clearanceRegion=None)
    #: The interaction "Int-5" has been created.

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#1000000 ]', ), )
    region1=regionToolset.Region(side1Edges=side1Edges1)
    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#400000 ]', ), )
    region2=regionToolset.Region(side1Edges=side1Edges1)
    mdb.models[ModelName].SurfaceToSurfaceContactStd(name='Int-6', 
        createStepName='Step-1', master=region1, slave=region2, sliding=FINITE, 
        thickness=ON, interactionProperty='IntProp-1', adjustMethod=NONE, 
        initialClearance=OMIT, datumAxis=None, clearanceRegion=None)
    #: The interaction "Int-6" has been created.

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#100000 ]', ), )
    region1=regionToolset.Region(side1Edges=side1Edges1)
    a = mdb.models[ModelName].rootAssembly
    f1 = a.instances['PART-1-1'].elements
    face2Elements1 = f1.getSequenceFromMask(mask=('[#21084210 #8421084 #2108421 ]', 
        ), )
    face4Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:2 #84000000 #21084210 #8421084 #42108421 #10842108 #84210842', 
        ' #4210 ]', ), )
    region2=regionToolset.Region(face2Elements=face2Elements1, 
        face4Elements=face4Elements1)
    mdb.models[ModelName].SurfaceToSurfaceContactStd(name='Int-7', 
        createStepName='Step-1', master=region1, slave=region2, sliding=FINITE, 
        thickness=ON, interactionProperty='IntProp-1', adjustMethod=NONE, 
        initialClearance=OMIT, datumAxis=None, clearanceRegion=None)
    #: The interaction "Int-7" has been created.

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-2-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#20 ]', ), )
    region1=regionToolset.Region(side1Edges=side1Edges1)
    a = mdb.models[ModelName].rootAssembly
    f1 = a.instances['PART-1-1'].elements
    face2Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:669 #10842100 #84210842 #21084210 ]', ), )
    face4Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:671 #40000000 #10842108 #84210842 #21084210 #8421084 #42108421', 
        ' #10842108 #2 ]', ), )
    region2=regionToolset.Region(face2Elements=face2Elements1, 
        face4Elements=face4Elements1)
    mdb.models[ModelName].SurfaceToSurfaceContactStd(name='Int-8', 
        createStepName='Step-1', master=region1, slave=region2, sliding=FINITE, 
        thickness=ON, interactionProperty='IntProp-1', adjustMethod=NONE, 
        initialClearance=OMIT, datumAxis=None, clearanceRegion=None)
    #: The interaction "Int-8" has been created.

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-2-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#c000000 ]', ), )
    region1=regionToolset.Region(side1Edges=side1Edges1)
    a = mdb.models[ModelName].rootAssembly
    f1 = a.instances['PART-1-1'].elements
    face2Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:126 #8420000 #42108421 #10842108 #84210842 #21084210 #84 ]', ), )
    face4Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:131 #10842100 #84210842 #21084210 #8421084 #42108421 ]', ), )
    region2=regionToolset.Region(face2Elements=face2Elements1, 
        face4Elements=face4Elements1)
    mdb.models[ModelName].SurfaceToSurfaceContactStd(name='Int-9', 
        createStepName='Step-1', master=region1, slave=region2, sliding=FINITE, 
        thickness=ON, interactionProperty='IntProp-1', adjustMethod=NONE, 
        initialClearance=OMIT, datumAxis=None, clearanceRegion=None)
    #: The interaction "Int-9" has been created.

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#30000 ]', ), )
    region1=regionToolset.Region(side1Edges=side1Edges1)
    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#8000 ]', ), )
    region2=regionToolset.Region(side1Edges=side1Edges1)
    mdb.models[ModelName].SurfaceToSurfaceContactStd(name='Int-10', 
        createStepName='Step-1', master=region1, slave=region2, sliding=FINITE, 
        thickness=ON, interactionProperty='IntProp-1', adjustMethod=NONE, 
        initialClearance=OMIT, datumAxis=None, clearanceRegion=None)
    #: The interaction "Int-10" has been created.

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#2000 ]', ), )
    region1=regionToolset.Region(side1Edges=side1Edges1)
    a = mdb.models[ModelName].rootAssembly
    f1 = a.instances['PART-1-1'].elements
    face2Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:34 #84000000 #21084210 #8421084 #42108421 #10842108 #84210842', 
        ' #4210 ]', ), )
    face4Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:40 #42108000 #10842108 #84210842 #10 ]', ), )
    region2=regionToolset.Region(face2Elements=face2Elements1, 
        face4Elements=face4Elements1)
    mdb.models[ModelName].SurfaceToSurfaceContactStd(name='Int-11', 
        createStepName='Step-1', master=region1, slave=region2, sliding=FINITE, 
        thickness=ON, interactionProperty='IntProp-1', adjustMethod=NONE, 
        initialClearance=OMIT, datumAxis=None, clearanceRegion=None)
    #: The interaction "Int-11" has been created.

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#800 ]', ), )
    region1=regionToolset.Region(side1Edges=side1Edges1)
    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#200 ]', ), )
    region2=regionToolset.Region(side1Edges=side1Edges1)
    mdb.models[ModelName].SurfaceToSurfaceContactStd(name='Int-12', 
        createStepName='Step-1', master=region1, slave=region2, sliding=FINITE, 
        thickness=ON, interactionProperty='IntProp-1', adjustMethod=NONE, 
        initialClearance=OMIT, datumAxis=None, clearanceRegion=None)
    #: The interaction "Int-12" has been created.

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#80 ]', ), )
    region1=regionToolset.Region(side1Edges=side1Edges1)
    a = mdb.models[ModelName].rootAssembly
    f1 = a.instances['PART-1-1'].elements
    face2Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:8 #10800000 #84210842 #21084210 #8421084 #42108421 #10842108 ]', ), )
    face4Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:13 #20000000 #8421084 #42108421 #842108 ]', ), )
    region2=regionToolset.Region(face2Elements=face2Elements1, 
        face4Elements=face4Elements1)
    mdb.models[ModelName].SurfaceToSurfaceContactStd(name='Int-13', 
        createStepName='Step-1', master=region1, slave=region2, sliding=FINITE, 
        thickness=ON, interactionProperty='IntProp-1', adjustMethod=NONE, 
        initialClearance=OMIT, datumAxis=None, clearanceRegion=None)
    #: The interaction "Int-13" has been created.

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-2-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#300000 ]', ), )
    region1=regionToolset.Region(side1Edges=side1Edges1)
    a = mdb.models[ModelName].rootAssembly
    f1 = a.instances['PART-1-1'].elements
    face2Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:171 #82082000 #20820820 #8208208 #82082082 #20820820 #8208208', 
        ' #2 ]', ), )
    face4Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:177 #4104104 #41041041 #10410410 #4104104 #41041041 #410410 ]', ), )
    region2=regionToolset.Region(face2Elements=face2Elements1, 
        face4Elements=face4Elements1)
    mdb.models[ModelName].SurfaceToSurfaceContactStd(name='Int-14', 
        createStepName='Step-1', master=region1, slave=region2, sliding=FINITE, 
        thickness=ON, interactionProperty='IntProp-1', adjustMethod=NONE, 
        initialClearance=OMIT, datumAxis=None, clearanceRegion=None)
    #: The interaction "Int-14" has been created.

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-2-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#200 ]', ), )
    region1=regionToolset.Region(side1Edges=side1Edges1)
    a = mdb.models[ModelName].rootAssembly
    f1 = a.instances['PART-1-1'].elements
    face2Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:678 #42108400 #10842108 #84210842 #210 ]', ), )
    face4Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:681 #42108400 #10842108 #84210842 #21084210 #8421084 #42108421', 
        ' #842108 ]', ), )
    region2=regionToolset.Region(face2Elements=face2Elements1, 
        face4Elements=face4Elements1)
    mdb.models[ModelName].SurfaceToSurfaceContactStd(name='Int-15', 
        createStepName='Step-1', master=region1, slave=region2, sliding=FINITE, 
        thickness=ON, interactionProperty='IntProp-1', adjustMethod=NONE, 
        initialClearance=OMIT, datumAxis=None, clearanceRegion=None)
    #: The interaction "Int-15" has been created.

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-2-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#3000 ]', ), )
    region1=regionToolset.Region(side1Edges=side1Edges1)
    a = mdb.models[ModelName].rootAssembly
    f1 = a.instances['PART-1-1'].elements
    face2Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:640 #41040000 #10410410 #4104104 #41041041 #10410410 #4104104', 
        ' #41041041 #10410 ]', ), )
    face4Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:634 #80000000 #20820820 #8208208 #82082082 #20820820 #8208208', 
        ' #82 ]', ), )
    region2=regionToolset.Region(face2Elements=face2Elements1, 
        face4Elements=face4Elements1)
    mdb.models[ModelName].SurfaceToSurfaceContactStd(name='Int-16', 
        createStepName='Step-1', master=region1, slave=region2, sliding=FINITE, 
        thickness=ON, interactionProperty='IntProp-1', adjustMethod=NONE, 
        initialClearance=OMIT, datumAxis=None, clearanceRegion=None)
    #: The interaction "Int-16" has been created.

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#20 ]', ), )
    region1=regionToolset.Region(side1Edges=side1Edges1)
    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#0 #200 ]', ), )
    region2=regionToolset.Region(side1Edges=side1Edges1)
    mdb.models[ModelName].SurfaceToSurfaceContactStd(name='Int-17', 
        createStepName='Step-1', master=region1, slave=region2, sliding=FINITE, 
        thickness=ON, interactionProperty='IntProp-1', adjustMethod=NONE, 
        initialClearance=OMIT, datumAxis=None, clearanceRegion=None)
    #: The interaction "Int-17" has been created.

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#0 #400 ]', ), )
    region1=regionToolset.Region(side1Edges=side1Edges1)
    a = mdb.models[ModelName].rootAssembly
    f1 = a.instances['PART-1-1'].elements
    face2Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:136 #8421080 #42108421 #10842108 #84210842 #21084210 #8421084', 
        ' #0:3 #20000000 #8421084 #42108421 #10842108 #84210842 #21084210', 
        ' #21084 ]', ), )
    face4Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:141 #10000000 #84210842 #21084210 #8421084 #108421 #0:5', 
        ' #10840000 #84210842 #210 ]', ), )
    region2=regionToolset.Region(face2Elements=face2Elements1, 
        face4Elements=face4Elements1)
    mdb.models[ModelName].SurfaceToSurfaceContactStd(name='Int-18', 
        createStepName='Step-1', master=region1, slave=region2, sliding=FINITE, 
        thickness=ON, interactionProperty='IntProp-1', adjustMethod=NONE, 
        initialClearance=OMIT, datumAxis=None, clearanceRegion=None)
    #: The interaction "Int-18" has been created.

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#10 ]', ), )
    region1=regionToolset.Region(side1Edges=side1Edges1)
    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#0 #80 ]', ), )
    region2=regionToolset.Region(side1Edges=side1Edges1)
    mdb.models[ModelName].SurfaceToSurfaceContactStd(name='Int-19', 
        createStepName='Step-1', master=region1, slave=region2, sliding=FINITE, 
        thickness=ON, interactionProperty='IntProp-1', adjustMethod=NONE, 
        initialClearance=OMIT, datumAxis=None, clearanceRegion=None)
    #: The interaction "Int-19" has been created.
    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#0 #100 ]', ), )
    region1=regionToolset.Region(side1Edges=side1Edges1)
    a = mdb.models[ModelName].rootAssembly
    f1 = a.instances['PART-1-1'].elements
    face2Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:617 #21000000 #8421084 #42108421 #10842108 #84210842 #21084210', 
        ' #1084 #42108400 #10842108 #84210842 #21084210 #8421084 #42108421', 
        ' #10842108 #84210842 ]', ), )
    face4Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:623 #10842000 #2 #0:7 #42108421 #10842108 #4210842 ]', ), )
    region2=regionToolset.Region(face2Elements=face2Elements1, 
        face4Elements=face4Elements1)
    mdb.models[ModelName].SurfaceToSurfaceContactStd(name='Int-20', 
        createStepName='Step-1', master=region1, slave=region2, sliding=FINITE, 
        thickness=ON, interactionProperty='IntProp-1', adjustMethod=NONE, 
        initialClearance=OMIT, datumAxis=None, clearanceRegion=None)
    #: The interaction "Int-20" has been created.

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#8 ]', ), )
    region1=regionToolset.Region(side1Edges=side1Edges1)
    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#0 #20 ]', ), )
    region2=regionToolset.Region(side1Edges=side1Edges1)
    mdb.models[ModelName].SurfaceToSurfaceContactStd(name='Int-21', 
        createStepName='Step-1', master=region1, slave=region2, sliding=FINITE, 
        thickness=ON, interactionProperty='IntProp-1', adjustMethod=NONE, 
        initialClearance=OMIT, datumAxis=None, clearanceRegion=None)
    #: The interaction "Int-21" has been created.

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#0 #40 ]', ), )
    region1=regionToolset.Region(side1Edges=side1Edges1)
    a = mdb.models[ModelName].rootAssembly
    f1 = a.instances['PART-1-1'].elements
    face2Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:153 #10840000 #84210842 #21084210 #8421084 #108421 #0', 
        ' #84000000 #21084210 #8421084 #108421 ]', ), )
    face4Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:157 #84200000 #21084210 #21084 #0:2 #84200000 #21084210', 
        ' #8421084 #42108421 #10842108 #84210842 #21084210 #8421084 #42108421', 
        ' #8 ]', ), )
    region2=regionToolset.Region(face2Elements=face2Elements1, 
        face4Elements=face4Elements1)
    mdb.models[ModelName].SurfaceToSurfaceContactStd(name='Int-22', 
        createStepName='Step-1', master=region1, slave=region2, sliding=FINITE, 
        thickness=ON, interactionProperty='IntProp-1', adjustMethod=NONE, 
        initialClearance=OMIT, datumAxis=None, clearanceRegion=None)
    #: The interaction "Int-22" has been created.

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-2-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#0 #80 ]', ), )
    region1=regionToolset.Region(side1Edges=side1Edges1)
    a = mdb.models[ModelName].rootAssembly
    f1 = a.instances['PART-1-1'].elements
    face2Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:208 #42108400 #10842108 #84210842 #21084210 #8421084 #42108421', 
        ' #10842108 #84210842 #210 ]', ), )
    face4Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:201 #42000000 #10842108 #84210842 #21084210 #8421084 #42108421', 
        ' #10842108 #2 #0:7 #42108400 #10842108 #84210842 #21084210', ' #421084 ]', 
        ), )
    region2=regionToolset.Region(face2Elements=face2Elements1, 
        face4Elements=face4Elements1)
    mdb.models[ModelName].SurfaceToSurfaceContactStd(name='Int-23', 
        createStepName='Step-1', master=region1, slave=region2, sliding=FINITE, 
        thickness=ON, interactionProperty='IntProp-1', adjustMethod=NONE, 
        initialClearance=OMIT, datumAxis=None, clearanceRegion=None)
    #: The interaction "Int-23" has been created.

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#4 ]', ), )
    region1=regionToolset.Region(side1Edges=side1Edges1)
    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#0 #8 ]', ), )
    region2=regionToolset.Region(side1Edges=side1Edges1)
    mdb.models[ModelName].SurfaceToSurfaceContactStd(name='Int-24', 
        createStepName='Step-1', master=region1, slave=region2, sliding=FINITE, 
        thickness=ON, interactionProperty='IntProp-1', adjustMethod=NONE, 
        initialClearance=OMIT, datumAxis=None, clearanceRegion=None)
    #: The interaction "Int-24" has been created.

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#0 #10 ]', ), )
    region1=regionToolset.Region(side1Edges=side1Edges1)
    a = mdb.models[ModelName].rootAssembly
    f1 = a.instances['PART-1-1'].elements
    face2Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:603 #8400000 #42108421 #10842108 #84210842 #21084210 #8421084', 
        ' #2108421 #0:4 #40000000 #10842108 #84210842 #84210 ]', ), )
    face4Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:600 #21000000 #8421084 #42108421 #2108 #0:5 #84000000', 
        ' #21084210 #8421084 #42108421 #10842108 #210842 ]', ), )
    region2=regionToolset.Region(face2Elements=face2Elements1, 
        face4Elements=face4Elements1)
    mdb.models[ModelName].SurfaceToSurfaceContactStd(name='Int-25', 
        createStepName='Step-1', master=region1, slave=region2, sliding=FINITE, 
        thickness=ON, interactionProperty='IntProp-1', adjustMethod=NONE, 
        initialClearance=OMIT, datumAxis=None, clearanceRegion=None)
    #: The interaction "Int-25" has been created.

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#2 ]', ), )
    region1=regionToolset.Region(side1Edges=side1Edges1)
    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#0 #2 ]', ), )
    region2=regionToolset.Region(side1Edges=side1Edges1)
    mdb.models[ModelName].SurfaceToSurfaceContactStd(name='Int-26', 
        createStepName='Step-1', master=region1, slave=region2, sliding=FINITE, 
        thickness=ON, interactionProperty='IntProp-1', adjustMethod=NONE, 
        initialClearance=OMIT, datumAxis=None, clearanceRegion=None)
    #: The interaction "Int-26" has been created.

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#0 #4 ]', ), )
    region1=regionToolset.Region(side1Edges=side1Edges1)
    a = mdb.models[ModelName].rootAssembly
    f1 = a.instances['PART-1-1'].elements
    face2Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:23 #10842100 #84210842 #21084210 #0:2 #10000000 #84210842', 
        ' #21084210 #421084 ]', ), )
    face4Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:16 #10000000 #84210842 #21084210 #8421084 #42108421 #10842108', 
        ' #84210842 #0:2 #40000000 #10842108 #84210842 #84210 #0:2', 
        ' #10800000 #84210842 #21084210 #21084 ]', ), )
    region2=regionToolset.Region(face2Elements=face2Elements1, 
        face4Elements=face4Elements1)
    mdb.models[ModelName].SurfaceToSurfaceContactStd(name='Int-27', 
        createStepName='Step-1', master=region1, slave=region2, sliding=FINITE, 
        thickness=ON, interactionProperty='IntProp-1', adjustMethod=NONE, 
        initialClearance=OMIT, datumAxis=None, clearanceRegion=None)
    #: The interaction "Int-27" has been created.

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#1 ]', ), )
    region1=regionToolset.Region(side1Edges=side1Edges1)
    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#80000000 ]', ), )
    region2=regionToolset.Region(side1Edges=side1Edges1)
    mdb.models[ModelName].SurfaceToSurfaceContactStd(name='Int-28', 
        createStepName='Step-1', master=region1, slave=region2, sliding=FINITE, 
        thickness=ON, interactionProperty='IntProp-1', adjustMethod=NONE, 
        initialClearance=OMIT, datumAxis=None, clearanceRegion=None)
    #: The interaction "Int-28" has been created.

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#0 #1 ]', ), )
    region1=regionToolset.Region(side1Edges=side1Edges1)
    a = mdb.models[ModelName].rootAssembly
    f1 = a.instances['PART-1-1'].elements
    face2Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:220 #80000000 #21084210 #8421084 #42108421 #10842108 #84210842', 
        ' #84210 #0:3 #84000000 #21084210 #8421084 #42108421 #10842108', 
        ' #84210842 #21084210 #8421084 #21 ]', ), )
    face4Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:226 #42100000 #10842108 #84210842 #21084210 #21084 ]', ), )
    region2=regionToolset.Region(face2Elements=face2Elements1, 
        face4Elements=face4Elements1)
    mdb.models[ModelName].SurfaceToSurfaceContactStd(name='Int-29', 
        createStepName='Step-1', master=region1, slave=region2, sliding=FINITE, 
        thickness=ON, interactionProperty='IntProp-1', adjustMethod=NONE, 
        initialClearance=OMIT, datumAxis=None, clearanceRegion=None)
    #: The interaction "Int-29" has been created.

    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-2-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#0 #20 ]', ), )
    region1=regionToolset.Region(side1Edges=side1Edges1)
    a = mdb.models[ModelName].rootAssembly
    f1 = a.instances['PART-1-1'].elements
    face2Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:186 #21084210 #8421084 #42108421 #10842108 #84210842 #21084210', 
        ' #8421084 #2108421 ]', ), )
    face4Elements1 = f1.getSequenceFromMask(mask=(
        '[#0:182 #10000000 #84210842 #21084210 #8421084 #0:7 #84000000', 
        ' #21084210 #8421084 #42108421 #10842108 #84210842 #21084210 #8421084', 
        ' #108421 ]', ), )
    region2=regionToolset.Region(face2Elements=face2Elements1, 
        face4Elements=face4Elements1)
    mdb.models[ModelName].SurfaceToSurfaceContactStd(name='Int-30', 
        createStepName='Step-1', master=region1, slave=region2, sliding=FINITE, 
        thickness=ON, interactionProperty='IntProp-1', adjustMethod=NONE, 
        initialClearance=OMIT, datumAxis=None, clearanceRegion=None)
    #: The interaction "Int-30" has been created.




    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#10 ]', ), )
    region1=regionToolset.Region(side1Edges=side1Edges1)
    a = mdb.models[ModelName].rootAssembly
    s1 = a.instances['Part-3-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#0 #80 ]', ), )
    region2=regionToolset.Region(side1Edges=side1Edges1)
    mdb.models[ModelName].SurfaceToSurfaceContactStd(name='Int-19', 
        createStepName='Step-1', master=region1, slave=region2, sliding=FINITE, 
        thickness=ON, interactionProperty='IntProp-1', adjustMethod=NONE, 
        initialClearance=OMIT, datumAxis=None, clearanceRegion=None)






    #del mdb.models[ModelName].loads['CFORCE-1']
    del mdb.models[ModelName].loads['SURFFLUX-1']
    del mdb.models[ModelName].loads['SURFFLUX-3']
    del mdb.models[ModelName].loads['SURFFLUX-2']
    del mdb.models[ModelName].loads['SURFFLUX-4']
    del mdb.models[ModelName].loads['SURFFLUX-5']
    del mdb.models[ModelName].loads['SURFFLUX-6']
    del mdb.models[ModelName].loads['SURFFLUX-7']
    del mdb.models[ModelName].loads['SURFFLUX-8']
    del mdb.models[ModelName].loads['SURFFLUX-9']
    del mdb.models[ModelName].loads['SURFFLUX-10']
    del mdb.models[ModelName].loads['SURFFLUX-11']
    del mdb.models[ModelName].loads['SURFFORCE-1']
    del mdb.models[ModelName].loads['SURFFORCE-2']

    a = mdb.models[ModelName].rootAssembly
    f1 = a.instances['Part-3-1'].faces
    faces1 = f1.getSequenceFromMask(mask=('[#1abf ]', ), )
    region = regionToolset.Region(faces=faces1)
    mdb.models[ModelName].BodyHeatFlux(name='Load-1', createStepName='Step-1', region=region, magnitude=10.0)
            
    del mdb.models[ModelName].boundaryConditions['Disp-BC-1']
    del mdb.models[ModelName].boundaryConditions['Disp-BC-2']
    del mdb.models[ModelName].predefinedFields['Field-1']

    a = mdb.models[ModelName].rootAssembly
    region = a.sets['RP-0']
    mdb.models[ModelName].EncastreBC(name='BC-1', createStepName='Initial', 
        region=region, localCsys=None)

    a = mdb.models[ModelName].rootAssembly
    e1 = a.instances['Part-2-1'].edges
    edges1 = e1.getSequenceFromMask(mask=('[#124a4555 #9 ]', ), )
    e2 = a.instances['Part-3-1'].edges
    edges2 = e2.getSequenceFromMask(mask=('[#2aac5540 ]', ), )
    region = regionToolset.Region(edges=edges1+edges2)
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].YsymmBC(name='BC-2', createStepName='Initial', 
        region=region, localCsys=datum)

    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=(
        '[#232020b0 #43000000 #5ac5c7a #0 #5ac0000 #0 #3307c000', 
        ' #fdc7c63f #7 #3ee7400 #7ae9 #e0000000 #1 #1e00000', 
        ' #0 #f0 #1e000000 #0:7 #80000000 #7 #fffe0000', 
        ' #0:5 #e0000000 #ff #0:6 #e0000 #0 #1c000', 
        ' #0:13 #1e0 #0 #78 #0:19 #f8000000 #ffffffff:3', 
        ' #ffffff #0:2 #ffffffe0 #7 #fc000000 #7fff #0', 
        ' #fff807f8 #1fffffff #0:15 #fe000000 #e0000001 #1f #1c01c', 
        ' #f0000000 #f #c0000000 #f #0 #3f ]', ), )
    region = regionToolset.Region(nodes=nodes1)
    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].YsymmBC(name='BC-3', createStepName='Initial', 
        region=region, localCsys=datum)

    a = mdb.models[ModelName].rootAssembly
    n1 = a.instances['PART-1-1'].nodes
    nodes1 = n1.getSequenceFromMask(mask=('[#ffffffff:720 #3ffff ]', ), )
    region = regionToolset.Region(nodes=nodes1)
    mdb.models[ModelName].Temperature(name='Predefined Field-1', 
        createStepName='Initial', region=region, distributionType=UNIFORM, 
        crossSectionDistribution=CONSTANT_THROUGH_THICKNESS, magnitudes=(948.0, ))
        
    a = mdb.models[ModelName].rootAssembly
    f1 = a.instances['Part-2-1'].faces
    faces1 = f1.getSequenceFromMask(mask=('[#1ff ]', ), )
    f2 = a.instances['Part-3-1'].faces
    faces2 = f2.getSequenceFromMask(mask=('[#fffff ]', ), )
    e2 = a.instances['Part-3-1'].edges
    edges2 = e2.getSequenceFromMask(mask=('[#8000 ]', ), )
    region = regionToolset.Region(edges=edges2, faces=faces1+faces2)
    mdb.models[ModelName].Temperature(name='Predefined Field-2', 
        createStepName='Initial', region=region, distributionType=UNIFORM, 
        crossSectionDistribution=CONSTANT_THROUGH_THICKNESS, magnitudes=(948.0, ))

    p = mdb.models[ModelName].parts['Part-2']
    p.seedPart(size=0.5, deviationFactor=0.1, minSizeFactor=0.1)
            
    p = mdb.models[ModelName].parts['Part-2']
    f = p.faces
    pickedRegions = f.getSequenceFromMask(mask=('[#1ff ]', ), )
    p.deleteMesh(regions=pickedRegions)
    p = mdb.models[ModelName].parts['Part-2']
    f = p.faces
    pickedRegions = f.getSequenceFromMask(mask=('[#1ff ]', ), )
    p.setMeshControls(regions=pickedRegions, algorithm=MEDIAL_AXIS)

    p = mdb.models[ModelName].parts['Part-2']
    p.generateMesh()

    elemType1 = mesh.ElemType(elemCode=CPEG4T, elemLibrary=STANDARD)
    elemType2 = mesh.ElemType(elemCode=CPE3T, elemLibrary=STANDARD)
    p = mdb.models[ModelName].parts['Part-2']
    f = p.faces
    faces = f.getSequenceFromMask(mask=('[#1ff ]', ), )
    pickedRegions =(faces, )
    p.setElementType(regions=pickedRegions, elemTypes=(elemType1, elemType2))

    p = mdb.models[ModelName].parts['Part-3']
    p.seedPart(size=0.5, deviationFactor=0.1, minSizeFactor=0.1)

    p = mdb.models[ModelName].parts['Part-3']
    f = p.faces
    pickedRegions = f.getSequenceFromMask(mask=('[#fffff ]', ), )
    p.setMeshControls(regions=pickedRegions, elemShape=QUAD, algorithm=MEDIAL_AXIS)

    elemType1 = mesh.ElemType(elemCode=CPEG4T, elemLibrary=STANDARD)
    elemType2 = mesh.ElemType(elemCode=CPE3T, elemLibrary=STANDARD)
    p = mdb.models[ModelName].parts['Part-3']
    f = p.faces
    faces = f.getSequenceFromMask(mask=('[#fffff ]', ), )
    pickedRegions =(faces, )
    p.setElementType(regions=pickedRegions, elemTypes=(elemType1, elemType2))

    p = mdb.models[ModelName].parts['Part-3']
    p.generateMesh()

    elemType1 = mesh.ElemType(elemCode=CPS4T, elemLibrary=STANDARD)
    elemType2 = mesh.ElemType(elemCode=CPE3T, elemLibrary=STANDARD)
    p = mdb.models[ModelName].parts['Part-3']
    f = p.faces
    faces = f.getSequenceFromMask(mask=('[#fffff ]', ), )
    pickedRegions =(faces, )
    p.setElementType(regions=pickedRegions, elemTypes=(elemType1, elemType2))

    elemType1 = mesh.ElemType(elemCode=CPS4T, elemLibrary=STANDARD)
    elemType2 = mesh.ElemType(elemCode=CPE3T, elemLibrary=STANDARD)
    p = mdb.models[ModelName].parts['Part-2']
    f = p.faces
    faces = f.getSequenceFromMask(mask=('[#1ff ]', ), )
    pickedRegions =(faces, )
    p.setElementType(regions=pickedRegions, elemTypes=(elemType1, elemType2))

    datum = mdb.models[ModelName].rootAssembly.datums[59]
    mdb.models[ModelName].boundaryConditions['BC-1'].setValues(
        localCsys=datum)
        
    p = mdb.models[ModelName].parts['Part-2']
    v, e, d, n = p.vertices, p.edges, p.datums, p.nodes
    p.ReferencePoint(point=p.InterestingPoint(edge=e[1], rule=CENTER))
    p = mdb.models[ModelName].parts['Part-3']
    p = mdb.models[ModelName].parts['Part-3']
    p.ReferencePoint(point=(0.0, 0.0, 0.0))

    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-3-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#80000 ]', ), )
    a.Set(vertices=verts1, name='red-out-top-2-2')
    #: The set 'red-out-top-2-2' has been edited (1 vertex).

    a = mdb.models[ModelName].rootAssembly
    v1 = a.instances['Part-3-1'].vertices
    verts1 = v1.getSequenceFromMask(mask=('[#8000000 ]', ), )
    a.Set(vertices=verts1, name='red-out-top-1')
    #: The set 'red-out-top-1' has been edited (1 vertex).

    mdb.models[ModelName].Equation(name='Constraint-36', terms=((1.0, 
        'RP-rod-5-in', 1, 59), (1.0, 'RP-rod-5-out', 1, 59), (-1.0, 'RP-0', 1, 
        59)))
    mdb.models[ModelName].constraints['Constraint-36'].setValues(terms=((1.0, 
        'RP-rod-5-in', 1, 59), (-1.0, 'RP-rod-5-out', 1, 59), (-1.0, 'RP-0', 1, 
        59)))
    mdb.models[ModelName].Constraint(name='Constraint-36-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-36'])
    mdb.models[ModelName].Constraint(name='Constraint-36-Copy-Copy', 
        objectToCopy=mdb.models[ModelName].constraints['Constraint-36-Copy'])
    mdb.models[ModelName].constraints['Constraint-36-Copy'].setValues(terms=((
        1.0, 'RP-rod-5-in', 2, 59), (-1.0, 'RP-rod-5-out', 2, 59), (-1.0, 'RP-0', 
        2, 59)))
    mdb.models[ModelName].constraints['Constraint-36-Copy-Copy'].setValues(
        terms=((1.0, 'RP-rod-5-in', 6, 59), (-1.0, 'RP-rod-5-out', 6, 59), (-1.0, 
        'RP-0', 6, 59)))

    mdb.models[ModelName].sections['Section-1-_I1'].setValues(
        material='MATERIAL01', thickness=1500.0, wedgeAngle1=0.0, wedgeAngle2=0.0)
            

